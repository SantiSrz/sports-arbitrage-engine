"""Motor de detección de surebets (arbitraje deportivo) en mercados de 2 y 3 vías.

Idea: para cada resultado se toma la mejor cuota disponible entre todas las
casas. Si ``Σ 1/cuota_i < 1`` existe un reparto de stakes que garantiza
beneficio sea cual sea el resultado.

    margen = 1 − Σ 1/cuota_i          (margen de arbitraje)
    ROI    = 1 / Σ 1/cuota_i − 1      (rentabilidad garantizada sobre el capital)
"""

from __future__ import annotations

import logging
from datetime import datetime, timedelta, timezone
from decimal import Decimal

from .exceptions import StakeRoundingError
from .market_selection import MarketSnapshot, build_market_snapshots
from .models import ArbitrageLeg, ArbitrageOpportunity, BookmakerMarket, Event
from .stakes import (
    evaluate_stakes,
    implied_probability,
    optimal_stakes,
    round_stakes,
    total_implied_probability,
)

logger = logging.getLogger(__name__)

_ZERO = Decimal(0)
_ONE = Decimal(1)


def _best_prices(snapshot: MarketSnapshot) -> dict[str, tuple[Decimal, BookmakerMarket]]:
    """Mejor cuota (y su casa) para cada resultado del snapshot."""
    best: dict[str, tuple[Decimal, BookmakerMarket]] = {}
    for name in snapshot.outcome_names:
        top: tuple[Decimal, BookmakerMarket] | None = None
        for entry in snapshot.entries:  # orden estable por clave => desempates deterministas
            price = entry.price_for(name)
            if price is not None and (top is None or price > top[0]):
                top = (price, entry)
        if top is None:  # imposible por construcción del snapshot; defensa extra
            raise ValueError(f"Sin cuotas para el resultado '{name}'.")
        best[name] = top
    return best


def _evaluate_snapshot(
    event: Event,
    snapshot: MarketSnapshot,
    *,
    bankroll: Decimal,
    min_margin: Decimal,
    round_step: Decimal | None,
    now: datetime,
) -> ArbitrageOpportunity | None:
    best = _best_prices(snapshot)
    names = snapshot.outcome_names
    odds = [best[n][0] for n in names]

    implied_sum = total_implied_probability(odds)
    margin = _ONE - implied_sum
    if implied_sum >= _ONE or margin < min_margin:
        return None

    roi = _ONE / implied_sum - _ONE
    ideal = optimal_stakes(odds, bankroll)
    theoretical_plan = evaluate_stakes(odds, ideal)

    rounded_plan = None
    if round_step is not None:
        try:
            rounded_plan = round_stakes(odds, ideal, max_total=bankroll, step=round_step)
        except StakeRoundingError as exc:
            logger.warning("Sin redondeo para %s (%s): %s", event.label, snapshot.market_key, exc)

    legs = tuple(
        ArbitrageLeg(
            outcome=name,
            bookmaker_key=best[name][1].bookmaker_key,
            bookmaker_title=best[name][1].bookmaker_title,
            odds=best[name][0],
            implied_probability=implied_probability(best[name][0]),
        )
        for name in names
    )
    return ArbitrageOpportunity(
        event=event,
        market_key=snapshot.market_key,
        structure=snapshot.structure,
        legs=legs,
        implied_sum=implied_sum,
        margin=margin,
        roi=roi,
        bankroll=bankroll,
        theoretical_plan=theoretical_plan,
        rounded_plan=rounded_plan,
        detected_at=now,
    )


def find_surebets(
    event: Event,
    *,
    bankroll: Decimal = Decimal("100"),
    min_margin: Decimal = _ZERO,
    round_step: Decimal | None = _ONE,
    max_odds_age: timedelta | None = None,
    include_live: bool = False,
    now: datetime | None = None,
) -> list[ArbitrageOpportunity]:
    """Busca surebets en todos los mercados soportados de un evento.

    Args:
        event: Evento con las cuotas de todas las casas.
        bankroll: Capital total a repartir entre las patas.
        min_margin: Margen de arbitraje mínimo como fracción (``0.01`` = 1 %).
        round_step: Paso de redondeo de stakes (``1`` = enteros). ``None`` desactiva
            el redondeo y sólo se calcula el plan teórico.
        max_odds_age: Ignora cuotas más antiguas que este intervalo.
        include_live: Permite eventos ya comenzados.
        now: Instante de referencia; por defecto, ahora en UTC.

    Returns:
        Oportunidades ordenadas de mayor a menor margen.

    Raises:
        ValueError: Si ``bankroll`` o ``min_margin`` no son válidos.
    """
    if not bankroll.is_finite() or bankroll <= _ZERO:
        raise ValueError(f"El bankroll debe ser > 0 (recibido: {bankroll}).")
    if min_margin < _ZERO:
        raise ValueError("min_margin no puede ser negativo.")
    reference_time = now or datetime.now(timezone.utc)

    opportunities: list[ArbitrageOpportunity] = []
    for snapshot in build_market_snapshots(
        event,
        now=reference_time,
        max_odds_age=max_odds_age,
        include_live=include_live,
        min_bookmakers=2,
    ):
        opportunity = _evaluate_snapshot(
            event,
            snapshot,
            bankroll=bankroll,
            min_margin=min_margin,
            round_step=round_step,
            now=reference_time,
        )
        if opportunity is not None:
            opportunities.append(opportunity)
    opportunities.sort(key=lambda o: o.margin, reverse=True)
    return opportunities
