"""Matemática de stakes: reparto óptimo, evaluación y redondeo.

Para ``n`` resultados mutuamente excluyentes con cuotas decimales ``o_i``::

    p_i       = 1 / o_i                    probabilidad implícita
    S         = Σ p_i                      suma de probabilidades implícitas
    stake_i   = B · p_i / S                reparto que iguala el retorno de cada resultado
    retorno   = B / S
    beneficio = B / S − B                  (> 0  ⇔  S < 1  ⇔  hay arbitraje)
"""

from __future__ import annotations

from collections.abc import Sequence
from decimal import ROUND_CEILING, ROUND_FLOOR, Decimal
from itertools import product

from .exceptions import InvalidOddsError, StakeRoundingError
from .models import StakePlan

_ZERO = Decimal(0)
_ONE = Decimal(1)
_MAX_COMBINATIONS = 200_000


def _validate_odds(odds: Sequence[Decimal]) -> None:
    if not odds:
        raise ValueError("Se necesita al menos una cuota.")
    for value in odds:
        if not value.is_finite() or value <= _ONE:
            raise InvalidOddsError(f"Cuota decimal inválida: {value} (debe ser > 1.0)")


def implied_probability(odds: Decimal) -> Decimal:
    """Probabilidad implícita de una cuota decimal: ``1 / cuota``."""
    if not odds.is_finite() or odds <= _ONE:
        raise InvalidOddsError(f"Cuota decimal inválida: {odds} (debe ser > 1.0)")
    return _ONE / odds


def total_implied_probability(odds: Sequence[Decimal]) -> Decimal:
    """Suma de probabilidades implícitas inversas ``Σ 1/cuota_i``.

    Un valor estrictamente menor que 1 indica oportunidad de arbitraje.
    """
    _validate_odds(odds)
    return sum((_ONE / o for o in odds), _ZERO)


def optimal_stakes(odds: Sequence[Decimal], bankroll: Decimal) -> tuple[Decimal, ...]:
    """Reparto teórico del ``bankroll`` que iguala el retorno en todos los resultados.

    Args:
        odds: Mejor cuota decimal de cada resultado.
        bankroll: Capital total a repartir (> 0).

    Returns:
        Stakes exactos (sin redondear) en el mismo orden que ``odds``.
    """
    if not bankroll.is_finite() or bankroll <= _ZERO:
        raise ValueError(f"El bankroll debe ser > 0 (recibido: {bankroll}).")
    total = total_implied_probability(odds)
    return tuple(bankroll * (_ONE / o) / total for o in odds)


def evaluate_stakes(odds: Sequence[Decimal], stakes: Sequence[Decimal]) -> StakePlan:
    """Calcula retornos y beneficio garantizado (peor caso) de un reparto dado."""
    _validate_odds(odds)
    if len(odds) != len(stakes):
        raise ValueError("odds y stakes deben tener la misma longitud.")
    if any(s < _ZERO for s in stakes):
        raise ValueError("Los stakes no pueden ser negativos.")
    total = sum(stakes, _ZERO)
    if total <= _ZERO:
        raise ValueError("El stake total debe ser > 0.")
    payouts = tuple(s * o for s, o in zip(stakes, odds, strict=True))
    return StakePlan(
        stakes=tuple(stakes),
        payouts=payouts,
        total_stake=total,
        guaranteed_profit=min(payouts) - total,
    )


def _candidate_range(ideal: Decimal, step: Decimal, radius: int) -> tuple[Decimal, ...]:
    """Múltiplos de ``step`` alrededor de ``ideal`` (mínimo 1 paso)."""
    units = ideal / step
    low = int(units.to_integral_value(rounding=ROUND_FLOOR)) - (radius - 1)
    high = int(units.to_integral_value(rounding=ROUND_CEILING)) + (radius - 1)
    return tuple(Decimal(k) * step for k in range(max(low, 1), max(high, 1) + 1))


def round_stakes(
    odds: Sequence[Decimal],
    ideal_stakes: Sequence[Decimal],
    *,
    max_total: Decimal,
    step: Decimal = _ONE,
    search_radius: int = 1,
) -> StakePlan:
    """Redondea los stakes a múltiplos de ``step`` (enteros por defecto).

    Muchas casas recreativas limitan o marcan las cuentas que apuestan importes
    "raros" (p. ej. 48,78 €). Redondear cada stake de forma independiente puede
    destruir el beneficio, así que se hace una búsqueda exhaustiva sobre los
    candidatos cercanos a cada stake ideal y se elige la combinación que:

    1. **Maximiza el beneficio garantizado** (peor escenario) → es la que mejor
       preserva el beneficio teórico.
    2. En caso de empate, minimiza la distancia L1 a los stakes ideales.
    3. En caso de empate, minimiza el capital total comprometido.

    Con ``search_radius=1`` los candidatos son ``floor`` y ``ceil`` de cada stake
    (2^n combinaciones; 8 para un mercado 1X2). Un radio mayor amplía la ventana.

    Args:
        odds: Cuotas decimales de cada resultado.
        ideal_stakes: Stakes teóricos (salida de :func:`optimal_stakes`).
        max_total: Capital máximo permitido; normalmente el bankroll.
        step: Granularidad del redondeo (``1`` = euros enteros, ``5`` = múltiplos de 5...).
        search_radius: Amplitud de la ventana de candidatos (>= 1).

    Raises:
        StakeRoundingError: Si ninguna combinación respeta ``max_total`` (p. ej.
            bankroll demasiado pequeño para apostar ``step`` en cada resultado) o
            el espacio de búsqueda es excesivo.
    """
    _validate_odds(odds)
    if len(odds) != len(ideal_stakes):
        raise ValueError("odds e ideal_stakes deben tener la misma longitud.")
    if not step.is_finite() or step <= _ZERO:
        raise ValueError("step debe ser > 0.")
    if search_radius < 1:
        raise ValueError("search_radius debe ser >= 1.")

    candidates = [_candidate_range(s, step, search_radius) for s in ideal_stakes]
    combinations = 1
    for options in candidates:
        combinations *= len(options)
    if combinations > _MAX_COMBINATIONS:
        raise StakeRoundingError(
            f"Espacio de búsqueda excesivo ({combinations} combinaciones); reduce search_radius."
        )

    best: tuple[Decimal, ...] | None = None
    best_key: tuple[Decimal, Decimal, Decimal] | None = None
    for combo in product(*candidates):
        total = sum(combo, _ZERO)
        if total > max_total:
            continue
        profit = min(s * o for s, o in zip(combo, odds, strict=True)) - total
        distance = sum(
            (abs(s - i) for s, i in zip(combo, ideal_stakes, strict=True)), _ZERO
        )
        key = (profit, -distance, -total)  # se maximiza lexicográficamente
        if best_key is None or key > best_key:
            best, best_key = combo, key

    if best is None:
        raise StakeRoundingError(
            f"Ningún reparto múltiplo de {step} cabe en {max_total}; "
            "aumenta el bankroll o reduce el paso de redondeo."
        )
    return evaluate_stakes(odds, best)
