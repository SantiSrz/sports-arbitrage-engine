"""Carga y validación de la configuración desde variables de entorno / ``.env``.

Variables reconocidas:

* ``ODDS_API_KEY`` (obligatoria): clave de The Odds API.
* ``ODDS_API_REGIONS``: regiones por defecto, separadas por comas (def. ``eu``).
* ``ODDS_API_TIMEOUT``: timeout HTTP en segundos (def. ``15``).
* ``ODDS_API_LOW_QUOTA_THRESHOLD``: umbral de aviso de créditos bajos (def. ``50``).
* ``DEFAULT_BANKROLL``: bankroll por defecto en las simulaciones (def. ``100``).
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from decimal import Decimal, InvalidOperation
from pathlib import Path

from dotenv import find_dotenv, load_dotenv

from .exceptions import ConfigurationError

_PLACEHOLDER_KEYS = frozenset({"", "your_api_key_here", "changeme", "xxx"})


def _env_str(name: str, default: str) -> str:
    value = os.environ.get(name)
    return value.strip() if value and value.strip() else default


def _env_float(name: str, default: float) -> float:
    raw = _env_str(name, "")
    if not raw:
        return default
    try:
        value = float(raw)
    except ValueError as exc:
        raise ConfigurationError(f"{name} debe ser numérico (recibido: {raw!r}).") from exc
    if value <= 0:
        raise ConfigurationError(f"{name} debe ser > 0 (recibido: {raw!r}).")
    return value


def _env_int(name: str, default: int) -> int:
    raw = _env_str(name, "")
    if not raw:
        return default
    try:
        value = int(raw)
    except ValueError as exc:
        raise ConfigurationError(f"{name} debe ser un entero (recibido: {raw!r}).") from exc
    if value < 0:
        raise ConfigurationError(f"{name} debe ser >= 0 (recibido: {raw!r}).")
    return value


def _env_decimal(name: str, default: Decimal) -> Decimal:
    raw = _env_str(name, "")
    if not raw:
        return default
    try:
        value = Decimal(raw)
    except InvalidOperation as exc:
        raise ConfigurationError(f"{name} debe ser un número (recibido: {raw!r}).") from exc
    if not value.is_finite() or value <= 0:
        raise ConfigurationError(f"{name} debe ser > 0 (recibido: {raw!r}).")
    return value


@dataclass(frozen=True, slots=True)
class Settings:
    """Configuración inmutable de la aplicación.

    ``api_key`` se excluye del ``repr`` para no filtrarla accidentalmente en logs.
    """

    api_key: str = field(repr=False)
    regions: tuple[str, ...] = ("eu",)
    request_timeout: float = 15.0
    low_quota_threshold: int = 50
    default_bankroll: Decimal = Decimal("100")

    @classmethod
    def from_env(
        cls,
        *,
        env_file: str | Path | None = None,
        require_api_key: bool = True,
    ) -> Settings:
        """Construye la configuración leyendo el entorno (y un ``.env`` si existe).

        Args:
            env_file: Ruta explícita a un ``.env``. Si es ``None`` se busca hacia
                arriba desde el directorio de trabajo.
            require_api_key: Si es ``False`` no falla cuando falta la API key
                (útil para el modo offline ``--from-file``).

        Raises:
            ConfigurationError: Si falta la API key o algún valor es inválido.
        """
        dotenv_path = str(env_file) if env_file else find_dotenv(usecwd=True)
        if dotenv_path:
            # override=False: las variables ya exportadas en el shell tienen prioridad.
            load_dotenv(dotenv_path=dotenv_path, override=False)

        api_key = _env_str("ODDS_API_KEY", "")
        if require_api_key and api_key.lower() in _PLACEHOLDER_KEYS:
            raise ConfigurationError(
                "Falta ODDS_API_KEY. Copia '.env.example' a '.env' y rellena tu clave "
                "(https://the-odds-api.com/)."
            )

        regions = tuple(
            r.strip().lower() for r in _env_str("ODDS_API_REGIONS", "eu").split(",") if r.strip()
        )
        if not regions:
            raise ConfigurationError("ODDS_API_REGIONS no puede estar vacío.")

        return cls(
            api_key=api_key,
            regions=regions,
            request_timeout=_env_float("ODDS_API_TIMEOUT", 15.0),
            low_quota_threshold=_env_int("ODDS_API_LOW_QUOTA_THRESHOLD", 50),
            default_bankroll=_env_decimal("DEFAULT_BANKROLL", Decimal("100")),
        )
