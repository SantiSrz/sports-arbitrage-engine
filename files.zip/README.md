# surebet-engine

Motor modular en Python para detectar **surebets** (arbitraje deportivo) y **valuebets** sobre
[The Odds API v4](https://the-odds-api.com/liveapi/guides/v4/). Requiere **Python ≥ 3.10**.

## Estructura

```
surebet-engine/
├── .env.example               # plantilla de variables de entorno
├── .gitignore
├── pyproject.toml             # config de pytest / mypy / ruff
├── requirements.txt           # requests, python-dotenv
├── requirements-dev.txt       # + pytest, mypy, ruff
├── examples/
│   └── sample_odds.json       # respuesta de ejemplo para probar sin gastar créditos
├── surebet_engine/
│   ├── __init__.py            # API pública del paquete
│   ├── __main__.py            # python -m surebet_engine
│   ├── config.py              # Settings + carga de ODDS_API_KEY con python-dotenv
│   ├── exceptions.py          # jerarquía de excepciones tipadas
│   ├── models.py              # dataclasses inmutables (Event, StakePlan, ArbitrageOpportunity...)
│   ├── odds_api_client.py     # cliente HTTP desacoplado (errores, reintentos, cuota)
│   ├── parsing.py             # JSON de la API -> modelos de dominio
│   ├── market_selection.py    # saneado: frescura, mercados completos, 1 entrada por casa
│   ├── stakes.py              # reparto óptimo, evaluación y redondeo de stakes
│   ├── arbitrage.py           # motor de surebets (2 y 3 vías)
│   ├── valuebet.py            # motor de valuebets (sin margen + Kelly)
│   ├── scanner.py             # orquestación cliente + motores
│   └── cli.py                 # CLI (sports / surebets / valuebets)
└── tests/
    ├── __init__.py
    └── test_engine.py
```

## Puesta en marcha

```bash
python -m venv .venv
source .venv/bin/activate            # Windows: .venv\Scripts\activate
pip install -r requirements-dev.txt

cp .env.example .env                 # Windows: copy .env.example .env
# edita .env y pon tu ODDS_API_KEY
```

## Uso

```bash
# Prueba offline (0 créditos). Las cuotas del ejemplo son antiguas, de ahí --max-age 0
python -m surebet_engine surebets  --from-file examples/sample_odds.json --max-age 0
python -m surebet_engine valuebets --from-file examples/sample_odds.json --max-age 0 --sharp pinnacle

# Deportes disponibles (según la documentación, este endpoint no consume créditos)
python -m surebet_engine sports

# Surebets en varias ligas, bankroll de 100 €, margen mínimo 0,5 %
python -m surebet_engine surebets --sport soccer_spain_la_liga --sport tennis_atp_paris_masters \
    --regions eu,uk --bankroll 100 --min-margin 0.5

# Valuebets contra Pinnacle como casa de referencia, salida JSON
python -m surebet_engine valuebets --sport basketball_nba --regions eu --sharp pinnacle \
    --min-edge 2 --kelly 0.25 --json
```

El coste de cada llamada a `/odds` es `nº de mercados × nº de regiones` créditos. El estado de la
cuota (`x-requests-remaining`, `x-requests-used`, `x-requests-last`) se muestra por `stderr` tras cada
ejecución y se emite un warning cuando quedan pocos créditos (`ODDS_API_LOW_QUOTA_THRESHOLD`).

Códigos de salida: `0` OK · `1` error de API/ejecución · `2` error de configuración o uso.

## Matemática

**Surebet** (n resultados con la mejor cuota `o_i` de cada uno):

```
S      = Σ 1/o_i                  hay arbitraje  ⇔  S < 1
margen = 1 − S
ROI    = 1/S − 1
stake_i = B · (1/o_i) / S         iguala el retorno en todos los resultados
beneficio garantizado = B/S − B
```

**Redondeo de stakes** (`stakes.round_stakes`): búsqueda exhaustiva sobre los candidatos `floor`/`ceil`
(ampliable con `search_radius`) de cada stake, respetando `capital ≤ bankroll`. Se elige la combinación
que **maximiza el beneficio garantizado en el peor escenario**; a igualdad, la más cercana a los stakes
ideales y, después, la de menor capital. `--round-step 5` redondea a múltiplos de 5.

**Valuebet**: se quita el margen de cada casa (multiplicativo o método de la potencia), se estima la
probabilidad justa (casa *sharp* o consenso *leave-one-out*) y se calcula `EV = p·cuota − 1`. El stake
sugerido usa Kelly fraccional (`--kelly`, def. 0,25) con tope sobre el bankroll (`--max-stake-pct`).

## Tests y calidad

```bash
python -m unittest discover -s tests -v     # o simplemente: pytest
mypy                                        # tipado estricto (config en pyproject.toml)
ruff check .
```

## Advertencias operativas

- **Cuotas obsoletas = falsos positivos.** Por eso se descartan cuotas con más de 15 min (`--max-age`) y
  los eventos en directo (`--include-live` para permitirlos).
- Un margen muy alto (>5 %) casi siempre es un error de datos o una cuota ya retirada: verifica en la casa
  antes de apostar.
- Tras el redondeo a enteros, el beneficio real puede quedar muy por debajo del teórico (o desaparecer si el
  margen es pequeño). La CLI lo marca con `⚠ SIN BENEFICIO tras redondear`.
- Las casas pueden limitar o cerrar cuentas que hagan arbitraje de forma sistemática, y las reglas de
  anulación de apuestas y la legalidad varían según casa y jurisdicción. Esto es una herramienta de análisis,
  no asesoramiento financiero.
