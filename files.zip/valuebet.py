"""Motor de valuebets: cuotas por encima de su valor justo estimado.

Método:

1. Para cada casa se eliminan los márgenes (*vig*) de sus cuotas y se obtienen
   probabilidades "justas" que suman 1 (:func:`remove_margin`).
2. La probabilidad de referencia se obtiene de:

   * una casa *sharp* (p. ej. ``pinnacle``) si se indica, o
   * el consenso (media) del resto de casas, excluyendo la casa evaluada
     (*leave-one-out*) para no sesgar la estimación.

3. Valor esperado por unidad apostada: ``EV = p_justa × cuota − 1``.
   Se marca valuebet si ``EV >= min_edge``.
4. Stake sugerido con criterio de Kelly fraccional y tope sobre el bankroll.

Aviso: la probabilidad justa es una *estimación*. Cuotas muy por encima del
consenso suelen ser errores o datos obsoletos, no valor real.
"""

from __future__ import annotations

from collections.abc import Sequence
from datetime import datetime, timedelta, timezone
from decimal import Decimal
from enum import Enum

from .market_selection import build_market_snapshots
from .models import BookmakerMarket, Event, ValueBet
from .stakes import total_implied_probability

_ZERO = Decimal(0)
_ONE = Decimal(1)


class MarginRemovalMethod(str, Enum):
    """Método para quitar el margen de la casa a un conjunto de cuotas."""

    MULTIPLICATIVE = "multiplicative"  # normaliza proporcionalmente
    POWER = "power"  # p_i^k con k tal que Σ p_i^k = 1 (penaliza menos a los favoritos)


def remove_margin(
    odds: Sequence[Decimal],
    method: MarginRemovalMethod = MarginRemovalMethod.MULTIPLICATIVE,
) -> tuple[Decimal, ...]:
    """Convierte cuotas en probabilidades justas que suman exactamente 1.

    Args:
        odds: Cuotas decimales de todos los resultados del mercado.
        method: Método de eliminación del margen.

    Returns:
        Probabilidades justas en el mismo orden que ``odds``.
    """
    book_sum = total_implied_probability(odds)  # valida las cuotas
    probabilities = [_ONE / o for o in odds]

    # Si no hay margen positivo (Σ <= 1) la normalización proporcional es suficiente.
    if method is MarginRemovalMethod.MULTIPLICATIVE or book_sum <= _ONE:
        return tuple(p / book_sum for p in probabilities)

    # Método de la potencia: bisección sobre k en [1, 200] (aritmética float acotada).
    floats = [float(p) for p in probabilities]
    low, high = 1.0, 200.0
    for _ in range(100):
        mid = (low + high) / 2
        if sum(p**mid for p in floats) > 1.0:
            low = mid
        else:
            high = mid
    exponent = (low + high) / 2
    powered = [Decimal(repr(p**exponent)) for p in floats]
    total = sum(powered, _ZERO)
    return tuple(p / total for p in powered)  # renormaliza residuos numéricos


def kelly_fraction(probability: Decimal, odds: Decimal) -> Decimal:
    """Fracción de Kelly completa ``f* = (p·cuota − 1) / (cuota − 1)`` (mínimo 0)."""
    if odds <= _ONE:
        raise ValueError("La cuota debe ser > 1.0.")
    fraction = (probability * odds - _ONE) / (odds - _ONE)
    return max(fraction, _ZERO)


def _price_vector(entry: BookmakerMarket, names: Sequence[str]) -> list[Decimal]:
    prices: list[Decimal] = []
    for name in names:
        price = entry.price_for(name)
        if price is None:  # imposible en un snapshot válido
            raise ValueError(f"{entry.bookmaker_key} no tiene cuota para '{name}'.")
        prices.append(price)
    return prices


def find_value_bets(
    event: Event,
    *,
    bankroll: Decimal = Decimal("100"),
    min_edge: Decimal = Decimal("0.02"),
    sharp_bookmaker: str | None = None,
    min_reference_bookmakers: int = 3,
    margin_method: MarginRemovalMethod = MarginRemovalMethod.MULTIPLICATIVE,
    kelly_multiplier: Decimal = Decimal("0.25"),
    max_stake_fraction: Decimal = Decimal("0.05"),
    max_odds_age: timedelta | None = None,
    include_live: bool = False,
    now: datetime | None = None,
) -> list[ValueBet]:
    """Busca valuebets en los mercados soportados de un evento.

    Args:
        event: Evento con las cuotas de todas las casas.
        bankroll: Capital total (base del stake sugerido).
        min_edge: Valor esperado mínimo como fracción (``0.02`` = +2 %).
        sharp_bookmaker: Clave de la casa de referencia. Si es ``None`` se usa
            el consenso leave-one-out del resto de casas.
        min_reference_bookmakers: Mínimo de casas de referencia en modo consenso.
        margin_method: Método para eliminar el margen de las casas de referencia.
        kelly_multiplier: Fracción de Kelly aplicada (``0.25`` = cuarto de Kelly).
        max_stake_fraction: Tope del stake como fracción del bankroll.
        max_odds_age: Ignora cuotas más antiguas que este intervalo.
        include_live: Permite eventos ya comenzados.
        now: Instante de referencia; por defecto, ahora en UTC.

    Returns:
        Valuebets ordenadas de mayor a menor valor esperado.

    Raises:
        ValueError: Si algún parámetro numérico es inválido.
    """
    if not bankroll.is_finite() or bankroll <= _ZERO:
        raise ValueError(f"El bankroll debe ser > 0 (recibido: {bankroll}).")
    if min_reference_bookmakers < 1:
        raise ValueError("min_reference_bookmakers debe ser >= 1.")
    if kelly_multiplier < _ZERO or max_stake_fraction < _ZERO:
        raise ValueError("kelly_multiplier y max_stake_fraction no pueden ser negativos.")
    reference_time = now or datetime.now(timezone.utc)

    min_books = 2 if sharp_bookmaker else min_reference_bookmakers + 1
    value_bets: list[ValueBet] = []

    for snapshot in build_market_snapshots(
        event,
        now=reference_time,
        max_odds_age=max_odds_age,
        include_live=include_live,
        min_bookmakers=min_books,
    ):
        names = snapshot.outcome_names
        fair_by_book: dict[str, dict[str, Decimal]] = {
            entry.bookmaker_key: dict(
                zip(names, remove_margin(_price_vector(entry, names), margin_method), strict=True)
            )
            for entry in snapshot.entries
        }
        if sharp_bookmaker and sharp_bookmaker not in fair_by_book:
            continue  # sin casa de referencia en este evento/mercado

        for candidate in snapshot.entries:
            if sharp_bookmaker:
                if candidate.bookmaker_key == sharp_bookmaker:
                    continue
                references = [sharp_bookmaker]
                label = sharp_bookmaker
            else:
                references = [k for k in fair_by_book if k != candidate.bookmaker_key]
                label = "consensus"
                if len(references) < min_reference_bookmakers:
                    continue

            for name in names:
                fair_p = sum((fair_by_book[r][name] for r in references), _ZERO) / len(references)
                price = candidate.price_for(name)
                if price is None or fair_p <= _ZERO:
                    continue
                expected_value = fair_p * price - _ONE
                if expected_value < min_edge or expected_value <= _ZERO:
                    continue

                full_kelly = kelly_fraction(fair_p, price)
                stake_fraction = min(full_kelly * kelly_multiplier, max_stake_fraction)
                value_bets.append(
                    ValueBet(
                        event=event,
                        market_key=snapshot.market_key,
                        outcome=name,
                        bookmaker_key=candidate.bookmaker_key,
                        bookmaker_title=candidate.bookmaker_title,
                        odds=price,
                        fair_probability=fair_p,
                        fair_odds=_ONE / fair_p,
                        expected_value=expected_value,
                        kelly_fraction=full_kelly,
                        recommended_stake=bankroll * stake_fraction,
                        reference_count=len(references),
                        reference_label=label,
                    )
                )

    value_bets.sort(key=lambda v: v.expected_value, reverse=True)
    return value_bets
