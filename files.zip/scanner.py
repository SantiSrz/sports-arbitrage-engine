"""Orquestación: descarga de eventos (cliente) + análisis (motores).

Mantiene desacoplados el cliente HTTP y la matemática: el scanner sólo los
compone. Las funciones ``scan_*`` son puras (no hacen red) y se pueden usar con
eventos leídos de disco o de una caché.
"""

from __future__ import annotations

import logging
from collections.abc import Iterable, Sequence
from datetime import datetime, timedelta, timezone
from decimal import Decimal

from .arbitrage import find_surebets
from .exceptions import (
    OddsApiRequestError,
    OddsApiResponseError,
    OddsApiServerError,
)
from .models import ArbitrageOpportunity, Event, ValueBet
from .odds_api_client import OddsApiClient
from .parsing import parse_events
from .valuebet import MarginRemovalMethod, find_value_bets

logger = logging.getLogger(__name__)


class OddsScanner:
    """Descarga eventos de The Odds API y los convierte en modelos de dominio."""

    def __init__(self, client: OddsApiClient) -> None:
        self._client = client

    def fetch_events(
        self,
        sport_keys: Sequence[str],
        *,
        regions: Sequence[str] = ("eu",),
        markets: Sequence[str] = ("h2h",),
        bookmakers: Sequence[str] | None = None,
    ) -> list[Event]:
        """Obtiene los eventos de uno o varios deportes.

        Un deporte que falle por parámetros inválidos, 404 o error del servidor
        se omite (con log de error) para no perder el resto. Los errores de
        autenticación, cuota, rate limit o red se propagan: no tiene sentido seguir.

        Raises:
            OddsApiQuotaExceededError: Créditos agotados.
            OddsApiAuthenticationError: API key inválida.
            OddsApiRateLimitError: Límite de frecuencia superado tras los reintentos.
            OddsApiConnectionError: Fallo de red.
        """
        events_by_id: dict[str, Event] = {}
        for sport_key in sport_keys:
            try:
                response = self._client.get_odds(
                    sport_key, regions=regions, markets=markets, bookmakers=bookmakers
                )
                events = parse_events(response.data)
            except (OddsApiRequestError, OddsApiServerError, OddsApiResponseError) as exc:
                logger.error("Se omite '%s': %s", sport_key, exc)
                continue
            logger.info("%s: %d evento(s) recibidos.", sport_key, len(events))
            for event in events:
                events_by_id[event.id] = event
        return list(events_by_id.values())


def scan_surebets(
    events: Iterable[Event],
    *,
    bankroll: Decimal,
    min_margin: Decimal = Decimal(0),
    round_step: Decimal | None = Decimal(1),
    max_odds_age: timedelta | None = None,
    include_live: bool = False,
    now: datetime | None = None,
) -> list[ArbitrageOpportunity]:
    """Busca surebets en una colección de eventos (ordenadas por margen desc.)."""
    reference_time = now or datetime.now(timezone.utc)
    found: list[ArbitrageOpportunity] = []
    for event in events:
        found.extend(
            find_surebets(
                event,
                bankroll=bankroll,
                min_margin=min_margin,
                round_step=round_step,
                max_odds_age=max_odds_age,
                include_live=include_live,
                now=reference_time,
            )
        )
    found.sort(key=lambda o: o.margin, reverse=True)
    return found


def scan_valuebets(
    events: Iterable[Event],
    *,
    bankroll: Decimal,
    min_edge: Decimal = Decimal("0.02"),
    sharp_bookmaker: str | None = None,
    min_reference_bookmakers: int = 3,
    margin_method: MarginRemovalMethod = MarginRemovalMethod.MULTIPLICATIVE,
    kelly_multiplier: Decimal = Decimal("0.25"),
    max_stake_fraction: Decimal = Decimal("0.05"),
    max_odds_age: timedelta | None = None,
    include_live: bool = False,
    now: datetime | None = None,
) -> list[ValueBet]:
    """Busca valuebets en una colección de eventos (ordenadas por EV desc.)."""
    reference_time = now or datetime.now(timezone.utc)
    found: list[ValueBet] = []
    for event in events:
        found.extend(
            find_value_bets(
                event,
                bankroll=bankroll,
                min_edge=min_edge,
                sharp_bookmaker=sharp_bookmaker,
                min_reference_bookmakers=min_reference_bookmakers,
                margin_method=margin_method,
                kelly_multiplier=kelly_multiplier,
                max_stake_fraction=max_stake_fraction,
                max_odds_age=max_odds_age,
                include_live=include_live,
                now=reference_time,
            )
        )
    found.sort(key=lambda v: v.expected_value, reverse=True)
    return found
