"""Motor modular de detección de surebets y valuebets sobre The Odds API v4."""

from .arbitrage import find_surebets
from .config import Settings
from .exceptions import (
    ConfigurationError,
    InvalidOddsError,
    OddsApiAuthenticationError,
    OddsApiConnectionError,
    OddsApiError,
    OddsApiQuotaExceededError,
    OddsApiRateLimitError,
    OddsApiRequestError,
    OddsApiResponseError,
    OddsApiServerError,
    StakeRoundingError,
    SurebetEngineError,
)
from .models import (
    ArbitrageLeg,
    ArbitrageOpportunity,
    BookmakerMarket,
    Event,
    MarketStructure,
    Outcome,
    QuotaInfo,
    Sport,
    StakePlan,
    ValueBet,
)
from .odds_api_client import ApiResponse, OddsApiClient
from .parsing import parse_events, parse_sports
from .scanner import OddsScanner, scan_surebets, scan_valuebets
from .stakes import (
    evaluate_stakes,
    implied_probability,
    optimal_stakes,
    round_stakes,
    total_implied_probability,
)
from .valuebet import MarginRemovalMethod, find_value_bets, kelly_fraction, remove_margin

__version__ = "0.1.0"

__all__ = [
    "ApiResponse",
    "ArbitrageLeg",
    "ArbitrageOpportunity",
    "BookmakerMarket",
    "ConfigurationError",
    "Event",
    "InvalidOddsError",
    "MarginRemovalMethod",
    "MarketStructure",
    "OddsApiAuthenticationError",
    "OddsApiClient",
    "OddsApiConnectionError",
    "OddsApiError",
    "OddsApiQuotaExceededError",
    "OddsApiRateLimitError",
    "OddsApiRequestError",
    "OddsApiResponseError",
    "OddsApiServerError",
    "OddsScanner",
    "Outcome",
    "QuotaInfo",
    "Settings",
    "Sport",
    "StakePlan",
    "StakeRoundingError",
    "SurebetEngineError",
    "ValueBet",
    "evaluate_stakes",
    "find_surebets",
    "find_value_bets",
    "implied_probability",
    "kelly_fraction",
    "optimal_stakes",
    "parse_events",
    "parse_sports",
    "remove_margin",
    "round_stakes",
    "scan_surebets",
    "scan_valuebets",
    "total_implied_probability",
]
