"""Tests unitarios del motor (unittest; también ejecutables con pytest).

    python -m unittest discover -s tests -v
    pytest
"""

from __future__ import annotations

import contextlib
import io
import json
import logging
import unittest
from datetime import datetime, timedelta, timezone
from decimal import Decimal
from pathlib import Path
from typing import Any, cast
from unittest import mock

import requests

from surebet_engine import (
    InvalidOddsError,
    MarginRemovalMethod,
    OddsApiAuthenticationError,
    OddsApiClient,
    OddsApiConnectionError,
    OddsApiQuotaExceededError,
    OddsApiRateLimitError,
    OddsApiRequestError,
    OddsApiResponseError,
    OddsApiServerError,
    StakeRoundingError,
    evaluate_stakes,
    find_surebets,
    find_value_bets,
    kelly_fraction,
    optimal_stakes,
    parse_events,
    remove_margin,
    round_stakes,
    total_implied_probability,
)
from surebet_engine.cli import main as cli_main
from surebet_engine.models import BookmakerMarket, Event, Outcome
from surebet_engine.odds_api_client import redact_api_key

D = Decimal
NOW = datetime(2026, 9, 29, 12, 0, tzinfo=timezone.utc)
FUTURE = NOW + timedelta(days=1)
SAMPLE_FILE = Path(__file__).resolve().parent.parent / "examples" / "sample_odds.json"


def market(
    bookmaker: str,
    prices: dict[str, str],
    *,
    last_update: datetime | None = NOW,
    market_key: str = "h2h",
) -> BookmakerMarket:
    return BookmakerMarket(
        bookmaker_key=bookmaker,
        bookmaker_title=bookmaker.title(),
        market_key=market_key,
        outcomes=tuple(Outcome(name, D(price)) for name, price in prices.items()),
        last_update=last_update,
    )


def event(markets: list[BookmakerMarket], *, commence: datetime = FUTURE) -> Event:
    return Event(
        id="evt1",
        sport_key="test_sport",
        sport_title="Test",
        commence_time=commence,
        home_team="Home",
        away_team="Away",
        markets=tuple(markets),
    )


class StakesTests(unittest.TestCase):
    ODDS = [D("2.10"), D("3.60"), D("4.50")]

    def test_total_implied_probability(self) -> None:
        self.assertEqual(total_implied_probability([D(2), D(2)]), D(1))
        self.assertLess(total_implied_probability(self.ODDS), D(1))

    def test_invalid_odds_rejected(self) -> None:
        with self.assertRaises(InvalidOddsError):
            total_implied_probability([D("1.0"), D("3.0")])

    def test_optimal_stakes_equalise_payouts_and_sum_to_bankroll(self) -> None:
        stakes = optimal_stakes(self.ODDS, D(100))
        plan = evaluate_stakes(self.ODDS, stakes)
        self.assertAlmostEqual(float(plan.total_stake), 100.0, places=9)
        self.assertAlmostEqual(float(plan.payouts[0]), float(plan.payouts[1]), places=9)
        self.assertAlmostEqual(float(plan.payouts[1]), float(plan.payouts[2]), places=9)
        expected = D(100) / total_implied_probability(self.ODDS) - D(100)
        self.assertAlmostEqual(float(plan.guaranteed_profit), float(expected), places=9)
        self.assertGreater(plan.guaranteed_profit, 0)

    def test_round_stakes_returns_integers_within_bankroll(self) -> None:
        ideal = optimal_stakes(self.ODDS, D(100))
        theoretical = evaluate_stakes(self.ODDS, ideal)
        plan = round_stakes(self.ODDS, ideal, max_total=D(100))
        self.assertTrue(all(s == s.to_integral_value() for s in plan.stakes))
        self.assertLessEqual(plan.total_stake, D(100))
        self.assertLessEqual(plan.guaranteed_profit, theoretical.guaranteed_profit)
        self.assertGreater(plan.guaranteed_profit, 0)

    def test_round_stakes_is_optimal_among_floor_ceil_candidates(self) -> None:
        ideal = optimal_stakes(self.ODDS, D(100))
        plan = round_stakes(self.ODDS, ideal, max_total=D(100))
        # Ninguna otra combinación floor/ceil dentro del bankroll mejora el resultado.
        import itertools

        options = [
            (s.to_integral_value(rounding="ROUND_FLOOR"), s.to_integral_value(rounding="ROUND_CEILING"))
            for s in ideal
        ]
        for combo in itertools.product(*options):
            if sum(combo, D(0)) > D(100):
                continue
            other = evaluate_stakes(self.ODDS, list(combo))
            self.assertLessEqual(other.guaranteed_profit, plan.guaranteed_profit)

    def test_round_stakes_custom_step(self) -> None:
        ideal = optimal_stakes([D("2.10"), D("2.05")], D(200))
        plan = round_stakes([D("2.10"), D("2.05")], ideal, max_total=D(200), step=D(5))
        self.assertTrue(all(s % 5 == 0 for s in plan.stakes))
        self.assertLessEqual(plan.total_stake, D(200))

    def test_round_stakes_infeasible_bankroll(self) -> None:
        odds = [D("3.2"), D("3.6"), D("3.5")]
        ideal = optimal_stakes(odds, D(2))
        with self.assertRaises(StakeRoundingError):
            round_stakes(odds, ideal, max_total=D(2))


class ArbitrageTests(unittest.TestCase):
    def test_two_way_surebet(self) -> None:
        ev = event(
            [
                market("book_a", {"Home": "2.10", "Away": "1.80"}),
                market("book_b", {"Home": "1.85", "Away": "2.10"}),
            ]
        )
        result = find_surebets(ev, bankroll=D(100), now=NOW)
        self.assertEqual(len(result), 1)
        opp = result[0]
        self.assertEqual(opp.structure.value, "2-way")
        self.assertAlmostEqual(float(opp.implied_sum), 0.952381, places=6)
        self.assertAlmostEqual(float(opp.margin), 0.047619, places=6)
        self.assertAlmostEqual(float(opp.roi), 0.05, places=9)
        self.assertAlmostEqual(float(opp.theoretical_plan.guaranteed_profit), 5.0, places=9)
        self.assertEqual([leg.bookmaker_key for leg in opp.legs], ["book_a", "book_b"])
        assert opp.rounded_plan is not None
        self.assertEqual(opp.rounded_plan.stakes, (D(50), D(50)))

    def test_three_way_surebet_with_draw(self) -> None:
        ev = event(
            [
                market("book_a", {"Home": "2.55", "Draw": "3.40", "Away": "2.90"}),
                market("book_b", {"Home": "2.40", "Draw": "3.75", "Away": "3.00"}),
                market("book_c", {"Home": "2.50", "Draw": "3.50", "Away": "3.15"}),
            ]
        )
        (opp,) = find_surebets(ev, bankroll=D(100), now=NOW)
        self.assertEqual(opp.structure.value, "3-way")
        self.assertEqual([leg.outcome for leg in opp.legs], ["Home", "Draw", "Away"])
        self.assertEqual([leg.bookmaker_key for leg in opp.legs], ["book_a", "book_b", "book_c"])
        self.assertLess(opp.implied_sum, D(1))

    def test_no_surebet_in_efficient_market(self) -> None:
        ev = event(
            [
                market("book_a", {"Home": "1.90", "Away": "1.90"}),
                market("book_b", {"Home": "1.85", "Away": "1.95"}),
            ]
        )
        self.assertEqual(find_surebets(ev, now=NOW), [])

    def test_min_margin_filter(self) -> None:
        ev = event(
            [
                market("book_a", {"Home": "2.10", "Away": "1.80"}),
                market("book_b", {"Home": "1.85", "Away": "2.10"}),
            ]
        )
        self.assertEqual(len(find_surebets(ev, min_margin=D("0.04"), now=NOW)), 1)
        self.assertEqual(find_surebets(ev, min_margin=D("0.05"), now=NOW), [])

    def test_stale_odds_are_ignored(self) -> None:
        old = NOW - timedelta(hours=2)
        ev = event(
            [
                market("book_a", {"Home": "2.10", "Away": "1.80"}, last_update=old),
                market("book_b", {"Home": "1.85", "Away": "2.10"}),
            ]
        )
        self.assertEqual(len(find_surebets(ev, now=NOW)), 1)
        self.assertEqual(find_surebets(ev, now=NOW, max_odds_age=timedelta(minutes=10)), [])

    def test_live_events_skipped_by_default(self) -> None:
        ev = event(
            [
                market("book_a", {"Home": "2.10", "Away": "1.80"}),
                market("book_b", {"Home": "1.85", "Away": "2.10"}),
            ],
            commence=NOW - timedelta(minutes=5),
        )
        self.assertEqual(find_surebets(ev, now=NOW), [])
        self.assertEqual(len(find_surebets(ev, now=NOW, include_live=True)), 1)

    def test_incomplete_bookmaker_market_is_ignored(self) -> None:
        # book_c sólo ofrece 2 de los 3 resultados: no debe contaminar el análisis.
        ev = event(
            [
                market("book_a", {"Home": "2.00", "Draw": "3.00", "Away": "3.00"}),
                market("book_b", {"Home": "2.00", "Draw": "3.00", "Away": "3.00"}),
                market("book_c", {"Home": "9.00", "Away": "9.00"}),
            ]
        )
        self.assertEqual(find_surebets(ev, now=NOW), [])

    def test_rounding_disabled(self) -> None:
        ev = event(
            [
                market("book_a", {"Home": "2.10", "Away": "1.80"}),
                market("book_b", {"Home": "1.85", "Away": "2.10"}),
            ]
        )
        (opp,) = find_surebets(ev, now=NOW, round_step=None)
        self.assertIsNone(opp.rounded_plan)
        self.assertEqual(opp.practical_plan, opp.theoretical_plan)

    def test_invalid_bankroll(self) -> None:
        with self.assertRaises(ValueError):
            find_surebets(event([]), bankroll=D(0), now=NOW)


class ValueBetTests(unittest.TestCase):
    def test_remove_margin_sums_to_one(self) -> None:
        odds = [D("2.10"), D("3.60"), D("3.40")]
        for method in MarginRemovalMethod:
            probs = remove_margin(odds, method)
            self.assertAlmostEqual(float(sum(probs, D(0))), 1.0, places=9)
        power = remove_margin(odds, MarginRemovalMethod.POWER)
        mult = remove_margin(odds, MarginRemovalMethod.MULTIPLICATIVE)
        # El método de la potencia asigna más probabilidad al favorito que el multiplicativo
        # y menos al outsider.
        self.assertGreater(power[0], mult[0])
        self.assertLess(power[1], mult[1])

    def test_kelly_fraction(self) -> None:
        self.assertEqual(kelly_fraction(D("0.55"), D("2.0")), D("0.10"))
        self.assertEqual(kelly_fraction(D("0.40"), D("2.0")), D(0))  # sin ventaja => 0

    def test_consensus_detects_outlier(self) -> None:
        ev = event(
            [
                market("a", {"Home": "1.95", "Away": "1.95"}),
                market("b", {"Home": "1.95", "Away": "1.95"}),
                market("c", {"Home": "1.95", "Away": "1.95"}),
                market("d", {"Home": "1.95", "Away": "2.30"}),
            ]
        )
        bets = find_value_bets(ev, bankroll=D(1000), now=NOW)
        self.assertEqual(len(bets), 1)
        bet = bets[0]
        self.assertEqual((bet.bookmaker_key, bet.outcome), ("d", "Away"))
        self.assertAlmostEqual(float(bet.fair_probability), 0.5, places=9)
        self.assertAlmostEqual(float(bet.expected_value), 0.15, places=9)
        # Kelly completo = 0.15/1.3 ≈ 11.5 %; cuarto de Kelly ≈ 2.88 % < tope 5 %.
        self.assertAlmostEqual(float(bet.recommended_stake), 1000 * 0.15 / 1.3 * 0.25, places=6)
        self.assertEqual(bet.reference_label, "consensus")

    def test_consensus_requires_minimum_references(self) -> None:
        ev = event(
            [
                market("a", {"Home": "1.95", "Away": "1.95"}),
                market("b", {"Home": "1.95", "Away": "1.95"}),
                market("d", {"Home": "1.95", "Away": "2.30"}),
            ]
        )
        self.assertEqual(find_value_bets(ev, now=NOW), [])  # sólo 2 referencias < 3
        self.assertEqual(len(find_value_bets(ev, now=NOW, min_reference_bookmakers=2)), 1)

    def test_sharp_bookmaker_reference(self) -> None:
        ev = event(
            [
                market("pinnacle", {"Home": "1.95", "Away": "1.95"}),
                market("soft", {"Home": "2.10", "Away": "1.80"}),
            ]
        )
        bets = find_value_bets(ev, now=NOW, sharp_bookmaker="pinnacle")
        self.assertEqual([(b.bookmaker_key, b.outcome) for b in bets], [("soft", "Home")])
        self.assertEqual(bets[0].reference_label, "pinnacle")
        self.assertAlmostEqual(float(bets[0].expected_value), 0.05, places=9)
        self.assertEqual(find_value_bets(ev, now=NOW, sharp_bookmaker="missing_book"), [])

    def test_stake_is_capped(self) -> None:
        ev = event(
            [
                market("pinnacle", {"Home": "1.95", "Away": "1.95"}),
                market("soft", {"Home": "3.00", "Away": "1.80"}),
            ]
        )
        (bet,) = find_value_bets(
            ev, bankroll=D(1000), now=NOW, sharp_bookmaker="pinnacle", kelly_multiplier=D(1)
        )
        self.assertEqual(bet.recommended_stake, D(50))  # tope 5 % de 1000


class ParsingTests(unittest.TestCase):
    def test_parse_events_is_tolerant(self) -> None:
        payload: list[dict[str, Any]] = [
            {
                "id": "e1",
                "sport_key": "soccer_epl",
                "sport_title": "EPL",
                "commence_time": "2026-10-01T18:00:00Z",
                "home_team": "A",
                "away_team": "B",
                "bookmakers": [
                    {
                        "key": "good",
                        "title": "Good",
                        "last_update": "2026-09-29T11:59:00Z",
                        "markets": [
                            {
                                "key": "h2h",
                                "outcomes": [
                                    {"name": "A", "price": 2.1},
                                    {"name": "B", "price": 1.8},
                                ],
                            }
                        ],
                    },
                    {
                        "key": "bad",
                        "title": "Bad",
                        "markets": [
                            {
                                "key": "h2h",
                                "outcomes": [
                                    {"name": "A", "price": "abc"},
                                    {"name": "B", "price": 1.8},
                                ],
                            }
                        ],
                    },
                ],
            },
            {"sport_key": "missing_id"},  # evento malformado
        ]
        events = parse_events(payload)
        self.assertEqual(len(events), 1)
        (ev,) = events
        self.assertEqual([m.bookmaker_key for m in ev.markets], ["good"])
        self.assertEqual(ev.markets[0].price_for("A"), D("2.1"))
        self.assertEqual(ev.markets[0].last_update, datetime(2026, 9, 29, 11, 59, tzinfo=timezone.utc))
        self.assertEqual(ev.commence_time.tzinfo, timezone.utc)

    def test_parse_events_rejects_non_list(self) -> None:
        with self.assertRaises(OddsApiResponseError):
            parse_events({"message": "oops"})


def make_response(
    status: int, body: Any, headers: dict[str, str] | None = None, *, raw: bytes | None = None
) -> requests.Response:
    response = requests.Response()
    response.status_code = status
    response._content = raw if raw is not None else json.dumps(body).encode()  # noqa: SLF001
    response.encoding = "utf-8"
    response.headers.update(headers or {})
    return response


class FakeSession:
    def __init__(self, response: requests.Response | Exception) -> None:
        self.response = response
        self.calls: list[tuple[str, dict[str, str], float]] = []

    def get(self, url: str, params: dict[str, str], timeout: float) -> requests.Response:
        self.calls.append((url, params, timeout))
        if isinstance(self.response, Exception):
            raise self.response
        return self.response

    def close(self) -> None:  # pragma: no cover
        pass


def client_with(response: requests.Response | Exception, **kwargs: Any) -> tuple[OddsApiClient, FakeSession]:
    session = FakeSession(response)
    client = OddsApiClient("SECRET123", session=cast(requests.Session, session), **kwargs)
    return client, session


class ClientTests(unittest.TestCase):
    def test_success_parses_quota_headers_and_builds_request(self) -> None:
        headers = {"x-requests-remaining": "487", "x-requests-used": "13", "x-requests-last": "2"}
        client, session = client_with(make_response(200, [], headers))
        response = client.get_odds("soccer_epl", regions=["eu", "uk"], markets=["h2h"])
        self.assertEqual(response.data, [])
        self.assertEqual(
            (response.quota.remaining, response.quota.used, response.quota.last_cost), (487, 13, 2)
        )
        self.assertEqual(client.last_quota, response.quota)
        url, params, _ = session.calls[0]
        self.assertTrue(url.endswith("/v4/sports/soccer_epl/odds"))
        self.assertEqual(params["apiKey"], "SECRET123")
        self.assertEqual(params["regions"], "eu,uk")
        self.assertEqual(params["markets"], "h2h")
        self.assertEqual(params["oddsFormat"], "decimal")

    def test_bookmakers_override_regions(self) -> None:
        client, session = client_with(make_response(200, []))
        client.get_odds("soccer_epl", regions=["eu"], bookmakers=["pinnacle", "bet365"])
        params = session.calls[0][1]
        self.assertEqual(params["bookmakers"], "pinnacle,bet365")
        self.assertNotIn("regions", params)

    def test_low_quota_emits_warning(self) -> None:
        headers = {"x-requests-remaining": "10"}
        client, _ = client_with(make_response(200, [], headers), low_quota_threshold=50)
        with self.assertLogs("surebet_engine.odds_api_client", level=logging.WARNING) as logs:
            client.get_sports()
        self.assertIn("pocos créditos", logs.output[0])

    def test_error_mapping(self) -> None:
        cases: list[tuple[int, dict[str, str], type[Exception]]] = [
            (401, {"message": "Usage quota exceeded", "error_code": "OUT_OF_USAGE_CREDITS"}, OddsApiQuotaExceededError),
            (401, {"message": "Invalid key", "error_code": "INVALID_KEY"}, OddsApiAuthenticationError),
            (429, {"message": "Too many", "error_code": "EXCEEDED_FREQ_LIMIT"}, OddsApiRateLimitError),
            (422, {"message": "Bad market", "error_code": "INVALID_MARKET"}, OddsApiRequestError),
            (404, {"message": "Unknown sport"}, OddsApiRequestError),
            (500, {"message": "boom"}, OddsApiServerError),
        ]
        for status, body, expected in cases:
            with self.subTest(status=status, code=body.get("error_code")):
                client, _ = client_with(make_response(status, body))
                with self.assertRaises(expected) as ctx:
                    client.get_odds("soccer_epl")
                self.assertEqual(cast(Any, ctx.exception).status_code, status)

    def test_invalid_json_body(self) -> None:
        client, _ = client_with(make_response(200, None, raw=b"<html>not json</html>"))
        with self.assertRaises(OddsApiResponseError):
            client.get_sports()

    def test_network_error_does_not_leak_api_key(self) -> None:
        error = requests.exceptions.ConnectionError(
            "HTTPSConnectionPool: Max retries exceeded with url: /v4/sports?apiKey=SECRET123&all=true"
        )
        client, _ = client_with(error)
        with self.assertRaises(OddsApiConnectionError) as ctx:
            client.get_sports()
        self.assertNotIn("SECRET123", str(ctx.exception))
        self.assertIn("apiKey=***", str(ctx.exception))

    def test_timeout_maps_to_connection_error(self) -> None:
        client, _ = client_with(requests.exceptions.Timeout("timed out"))
        with self.assertRaises(OddsApiConnectionError):
            client.get_sports()

    def test_input_validation(self) -> None:
        client, _ = client_with(make_response(200, []))
        with self.assertRaises(ValueError):
            client.get_odds("../etc/passwd")
        with self.assertRaises(ValueError):
            client.get_odds("soccer_epl", markets=[])
        with self.assertRaises(ValueError):
            OddsApiClient("   ")

    def test_redact_api_key(self) -> None:
        self.assertEqual(redact_api_key("GET /x?apiKey=abc123&y=1"), "GET /x?apiKey=***&y=1")


class CliTests(unittest.TestCase):
    def run_cli(self, *argv: str) -> tuple[int, str, str]:
        out, err = io.StringIO(), io.StringIO()
        with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
            code = cli_main(list(argv))
        return code, out.getvalue(), err.getvalue()

    def test_surebets_from_file_text_output(self) -> None:
        code, out, _ = self.run_cli("surebets", "--from-file", str(SAMPLE_FILE), "--max-age", "0")
        self.assertEqual(code, 0)
        self.assertIn("Surebets encontradas: 2", out)
        self.assertIn("Carlos Alcaraz vs Jannik Sinner", out)

    def test_surebets_from_file_json_output(self) -> None:
        code, out, _ = self.run_cli(
            "surebets", "--from-file", str(SAMPLE_FILE), "--max-age", "0", "--json", "--bankroll", "200"
        )
        self.assertEqual(code, 0)
        data = json.loads(out)
        self.assertEqual(data["count"], 2)
        self.assertEqual(data["surebets"][0]["bankroll"], "200.00")

    def test_valuebets_from_file(self) -> None:
        code, out, _ = self.run_cli(
            "valuebets", "--from-file", str(SAMPLE_FILE), "--max-age", "0", "--sharp", "pinnacle", "--json"
        )
        self.assertEqual(code, 0)
        self.assertGreater(json.loads(out)["count"], 0)

    def test_missing_api_key_returns_config_error(self) -> None:
        with mock.patch.dict("os.environ", {"ODDS_API_KEY": ""}, clear=False), mock.patch(
            "surebet_engine.config.find_dotenv", return_value=""
        ):
            code, _, err = self.run_cli("sports")
        self.assertEqual(code, 2)
        self.assertIn("ODDS_API_KEY", err)

    def test_missing_sport_returns_config_error(self) -> None:
        with mock.patch.dict("os.environ", {"ODDS_API_KEY": "abc"}, clear=False):
            code, _, err = self.run_cli("surebets")
        self.assertEqual(code, 2)
        self.assertIn("--sport", err)


if __name__ == "__main__":
    unittest.main()
