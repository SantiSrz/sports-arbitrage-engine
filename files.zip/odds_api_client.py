"""Cliente HTTP desacoplado para The Odds API v4.

Responsabilidades (y sólo estas):

* Construir las peticiones y gestionar cabeceras, timeouts y reintentos.
* Traducir los códigos de error HTTP / ``error_code`` a excepciones tipadas.
* Leer ``x-requests-remaining``, ``x-requests-used`` y ``x-requests-last`` para
  monitorizar el consumo del plan gratuito.
* No filtrar la API key en logs ni en mensajes de excepción.

El cliente devuelve JSON "crudo" (:class:`ApiResponse`); la conversión a modelos
de dominio vive en :mod:`surebet_engine.parsing`.
"""

from __future__ import annotations

import logging
import re
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from types import TracebackType
from typing import Any

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

from .exceptions import (
    OddsApiAuthenticationError,
    OddsApiConnectionError,
    OddsApiError,
    OddsApiQuotaExceededError,
    OddsApiRateLimitError,
    OddsApiRequestError,
    OddsApiResponseError,
    OddsApiServerError,
)
from .models import QuotaInfo

logger = logging.getLogger(__name__)

DEFAULT_BASE_URL = "https://api.the-odds-api.com/v4"

_SPORT_KEY_RE = re.compile(r"[A-Za-z0-9_]+")
_API_KEY_RE = re.compile(r"(apiKey=)[^&\s'\"]+", re.IGNORECASE)


def redact_api_key(text: str) -> str:
    """Enmascara cualquier ``apiKey=...`` presente en ``text``."""
    return _API_KEY_RE.sub(r"\1***", text)


@dataclass(frozen=True, slots=True)
class ApiResponse:
    """Respuesta JSON decodificada junto con el estado de la cuota."""

    data: Any
    quota: QuotaInfo


def _int_header(headers: Mapping[str, str], name: str) -> int | None:
    """Lee una cabecera numérica; devuelve ``None`` si falta o no es válida."""
    raw = headers.get(name)
    if raw is None:
        return None
    try:
        return int(float(raw))
    except (TypeError, ValueError, OverflowError):
        logger.debug("Cabecera %s con valor no numérico: %r", name, raw)
        return None


def parse_quota_headers(headers: Mapping[str, str]) -> QuotaInfo:
    """Extrae el consumo del plan de las cabeceras de la respuesta."""
    return QuotaInfo(
        remaining=_int_header(headers, "x-requests-remaining"),
        used=_int_header(headers, "x-requests-used"),
        last_cost=_int_header(headers, "x-requests-last"),
    )


class OddsApiClient:
    """Cliente de The Odds API v4.

    Puede usarse como *context manager* para cerrar la sesión HTTP:

    >>> with OddsApiClient(api_key="...") as client:          # doctest: +SKIP
    ...     response = client.get_odds("soccer_epl", regions=["eu"])
    ...     print(client.last_quota.remaining)

    Args:
        api_key: Clave de la API (nunca se registra en logs).
        base_url: URL base; por defecto la v4 oficial.
        timeout: Timeout (segundos) de cada petición HTTP.
        low_quota_threshold: Se emite un warning si los créditos restantes
            son menores o iguales que este valor.
        max_retries: Reintentos automáticos ante 429/5xx con *backoff*.
        session: Sesión ``requests`` inyectable (útil en tests). Si se aporta,
            el cliente no le monta reintentos ni la cierra.
    """

    def __init__(
        self,
        api_key: str,
        *,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = 15.0,
        low_quota_threshold: int = 50,
        max_retries: int = 3,
        session: requests.Session | None = None,
    ) -> None:
        if not api_key or not api_key.strip():
            raise ValueError("api_key no puede estar vacía.")
        self._api_key = api_key.strip()
        self._base_url = base_url.rstrip("/")
        self._timeout = timeout
        self._low_quota_threshold = low_quota_threshold
        self._last_quota = QuotaInfo()

        self._owns_session = session is None
        self._session = session if session is not None else self._build_session(max_retries)

    # ------------------------------------------------------------------ #
    # Ciclo de vida
    # ------------------------------------------------------------------ #
    @staticmethod
    def _build_session(max_retries: int) -> requests.Session:
        session = requests.Session()
        retry = Retry(
            total=max_retries,
            backoff_factor=0.8,
            status_forcelist=(429, 500, 502, 503, 504),
            allowed_methods=frozenset({"GET"}),
            respect_retry_after_header=True,
            # Al agotar reintentos devolvemos la última respuesta para mapearla
            # nosotros a una excepción tipada, en lugar de un RetryError genérico.
            raise_on_status=False,
        )
        adapter = HTTPAdapter(max_retries=retry)
        session.mount("https://", adapter)
        session.mount("http://", adapter)
        session.headers.update(
            {"Accept": "application/json", "User-Agent": "surebet-engine/0.1"}
        )
        return session

    def close(self) -> None:
        """Cierra la sesión HTTP si fue creada por este cliente."""
        if self._owns_session:
            self._session.close()

    def __enter__(self) -> OddsApiClient:
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        tb: TracebackType | None,
    ) -> None:
        self.close()

    @property
    def last_quota(self) -> QuotaInfo:
        """Estado de la cuota según la última respuesta recibida."""
        return self._last_quota

    # ------------------------------------------------------------------ #
    # Endpoints
    # ------------------------------------------------------------------ #
    def get_sports(self, *, all_sports: bool = False) -> ApiResponse:
        """Lista los deportes disponibles (``GET /v4/sports``).

        Según la documentación oficial este endpoint no consume créditos.

        Args:
            all_sports: Incluye también los deportes fuera de temporada.
        """
        params: dict[str, str] = {}
        if all_sports:
            params["all"] = "true"
        return self._request("sports", params)

    def get_odds(
        self,
        sport_key: str,
        *,
        regions: Sequence[str] = ("eu",),
        markets: Sequence[str] = ("h2h",),
        bookmakers: Sequence[str] | None = None,
        event_ids: Sequence[str] | None = None,
    ) -> ApiResponse:
        """Cuotas de un deporte (``GET /v4/sports/{sport}/odds``).

        Siempre solicita ``oddsFormat=decimal`` y ``dateFormat=iso``, que es lo
        que espera el motor. El coste en créditos es ``nº_mercados × nº_regiones``.

        Args:
            sport_key: Clave del deporte (p. ej. ``soccer_spain_la_liga``) o ``upcoming``.
            regions: Regiones de casas de apuestas (``eu``, ``uk``, ``us``, ``us2``, ``au``).
            markets: Mercados (``h2h`` para ganador / 1X2).
            bookmakers: Claves concretas de casas; si se indican, la API
                ignora ``regions``.
            event_ids: Restringe la respuesta a estos eventos.

        Raises:
            ValueError: Si ``sport_key`` es inválido o faltan mercados/regiones.
            OddsApiError: Ante cualquier error de la API o de red.
        """
        if not _SPORT_KEY_RE.fullmatch(sport_key):
            raise ValueError(f"sport_key inválido: {sport_key!r}")
        if not markets:
            raise ValueError("Debe indicarse al menos un mercado.")

        params: dict[str, str] = {
            "markets": ",".join(markets),
            "oddsFormat": "decimal",
            "dateFormat": "iso",
        }
        if bookmakers:
            params["bookmakers"] = ",".join(bookmakers)
        else:
            if not regions:
                raise ValueError("Debe indicarse al menos una región o una casa.")
            params["regions"] = ",".join(regions)
        if event_ids:
            params["eventIds"] = ",".join(event_ids)

        return self._request(f"sports/{sport_key}/odds", params)

    # ------------------------------------------------------------------ #
    # Núcleo HTTP
    # ------------------------------------------------------------------ #
    def _request(self, path: str, params: Mapping[str, str]) -> ApiResponse:
        url = f"{self._base_url}/{path.lstrip('/')}"
        query = {"apiKey": self._api_key, **params}

        try:
            response = self._session.get(url, params=query, timeout=self._timeout)
        except requests.exceptions.Timeout as exc:
            raise OddsApiConnectionError(
                f"Timeout tras {self._timeout}s en GET /{path}: {redact_api_key(str(exc))}"
            ) from None  # 'from None': el traceback encadenado podría contener la key
        except requests.exceptions.RequestException as exc:
            raise OddsApiConnectionError(
                f"Error de red en GET /{path}: {redact_api_key(str(exc))}"
            ) from None

        quota = parse_quota_headers(response.headers)
        self._register_quota(quota)
        logger.debug(
            "GET /%s -> HTTP %s | créditos restantes=%s usados=%s último coste=%s",
            path,
            response.status_code,
            quota.remaining,
            quota.used,
            quota.last_cost,
        )

        if response.status_code != 200:
            raise self._build_error(response)

        try:
            data = response.json()
        except ValueError:
            raise OddsApiResponseError(
                f"La respuesta de GET /{path} no es JSON válido.",
                status_code=response.status_code,
            ) from None
        return ApiResponse(data=data, quota=quota)

    def _register_quota(self, quota: QuotaInfo) -> None:
        """Guarda la cuota y avisa si quedan pocos créditos."""
        self._last_quota = quota
        if quota.remaining is None:
            return
        if quota.remaining == 0:
            logger.error("Créditos de The Odds API agotados (remaining=0).")
        elif quota.remaining <= self._low_quota_threshold:
            logger.warning(
                "Quedan pocos créditos en The Odds API: %s (umbral: %s).",
                quota.remaining,
                self._low_quota_threshold,
            )

    @staticmethod
    def _extract_error(response: requests.Response) -> tuple[str, str | None]:
        """Obtiene ``(mensaje, error_code)`` del cuerpo de una respuesta de error."""
        try:
            body = response.json()
        except ValueError:
            text = (response.text or "").strip()[:200]
            return redact_api_key(text or response.reason or "sin detalle"), None
        if isinstance(body, dict):
            message = str(body.get("message") or body.get("error") or "sin detalle")
            code = body.get("error_code")
            return redact_api_key(message), str(code) if code else None
        return redact_api_key(str(body)[:200]), None

    def _build_error(self, response: requests.Response) -> OddsApiError:
        """Mapea una respuesta HTTP no exitosa a una excepción tipada."""
        status = response.status_code
        message, code = self._extract_error(response)
        text = f"HTTP {status}" + (f" [{code}]" if code else "") + f": {message}"
        kwargs: dict[str, Any] = {"status_code": status, "error_code": code}

        if code == "OUT_OF_USAGE_CREDITS":
            return OddsApiQuotaExceededError(f"Créditos agotados. {text}", **kwargs)
        if code == "EXCEEDED_FREQ_LIMIT" or status == 429:
            return OddsApiRateLimitError(f"Límite de frecuencia superado. {text}", **kwargs)
        if status in (401, 403):
            return OddsApiAuthenticationError(f"Autenticación fallida. {text}", **kwargs)
        if 400 <= status < 500:
            return OddsApiRequestError(f"Petición rechazada. {text}", **kwargs)
        if status >= 500:
            return OddsApiServerError(f"Error del servidor. {text}", **kwargs)
        return OddsApiError(f"Respuesta inesperada. {text}", **kwargs)
