"""Jerarquía de excepciones del motor de surebets/valuebets.

Todas heredan de :class:`SurebetEngineError`, de modo que la CLI (o cualquier
consumidor) puede capturar una única clase base y decidir qué hacer.
"""

from __future__ import annotations


class SurebetEngineError(Exception):
    """Excepción base de toda la aplicación."""


class ConfigurationError(SurebetEngineError):
    """Configuración ausente o inválida (p. ej. falta ``ODDS_API_KEY``)."""


class InvalidOddsError(SurebetEngineError, ValueError):
    """Cuota inválida: no numérica, no finita o menor/igual que 1.0."""


class StakeRoundingError(SurebetEngineError):
    """No existe un reparto de stakes redondeados que cumpla las restricciones."""


class OddsApiError(SurebetEngineError):
    """Error genérico devuelto por (o al comunicarse con) The Odds API.

    Attributes:
        status_code: Código HTTP de la respuesta, si existe.
        error_code: Código de error de la API (p. ej. ``OUT_OF_USAGE_CREDITS``).
    """

    def __init__(
        self,
        message: str,
        *,
        status_code: int | None = None,
        error_code: str | None = None,
    ) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.error_code = error_code


class OddsApiConnectionError(OddsApiError):
    """Fallo de red, timeout o error de TLS al contactar con la API."""


class OddsApiAuthenticationError(OddsApiError):
    """API key ausente, inválida o desactivada."""


class OddsApiQuotaExceededError(OddsApiError):
    """Se han agotado los créditos del plan (``OUT_OF_USAGE_CREDITS``)."""


class OddsApiRateLimitError(OddsApiError):
    """Demasiadas peticiones por segundo (HTTP 429)."""


class OddsApiRequestError(OddsApiError):
    """Petición rechazada por parámetros inválidos o recurso inexistente (4xx)."""


class OddsApiServerError(OddsApiError):
    """Error interno del servidor de la API (5xx)."""


class OddsApiResponseError(OddsApiError):
    """La respuesta no es JSON válido o no tiene la estructura esperada."""
