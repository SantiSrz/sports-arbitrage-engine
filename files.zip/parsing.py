"""Conversión del JSON crudo de The Odds API a modelos de dominio tipados.

El parseo es tolerante: un evento o un mercado malformado se descarta con un
warning en lugar de abortar todo el análisis.
"""

from __future__ import annotations

import logging
from collections.abc import Iterator, Mapping
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation
from typing import Any

from .exceptions import InvalidOddsError, OddsApiResponseError
from .models import BookmakerMarket, Event, Outcome, Sport

logger = logging.getLogger(__name__)


def _parse_datetime(value: Any) -> datetime:
    """Parsea un timestamp ISO-8601 (admite sufijo ``Z``) a datetime UTC-aware."""
    if not isinstance(value, str):
        raise ValueError(f"Timestamp inválido: {value!r}")
    parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed


def _parse_price(value: Any) -> Decimal:
    """Convierte una cuota JSON a ``Decimal`` sin pasar por errores de float."""
    if isinstance(value, bool) or value is None:
        raise InvalidOddsError(f"Cuota no numérica: {value!r}")
    try:
        return Decimal(str(value))
    except InvalidOperation:
        raise InvalidOddsError(f"Cuota no numérica: {value!r}") from None


def _parse_bookmaker_markets(raw_bookmaker: Mapping[str, Any]) -> Iterator[BookmakerMarket]:
    """Genera los mercados válidos de una casa; descarta los malformados."""
    bookmaker_key = str(raw_bookmaker["key"])
    bookmaker_title = str(raw_bookmaker.get("title") or bookmaker_key)
    for raw_market in raw_bookmaker.get("markets") or []:
        try:
            outcomes = tuple(
                Outcome(name=str(o["name"]), price=_parse_price(o["price"]))
                for o in raw_market["outcomes"]
            )
            last_raw = raw_market.get("last_update") or raw_bookmaker.get("last_update")
            yield BookmakerMarket(
                bookmaker_key=bookmaker_key,
                bookmaker_title=bookmaker_title,
                market_key=str(raw_market["key"]),
                outcomes=outcomes,
                last_update=_parse_datetime(last_raw) if last_raw else None,
            )
        except (KeyError, TypeError, ValueError) as exc:  # InvalidOddsError es ValueError
            logger.debug(
                "Mercado descartado (%s / %s): %s",
                bookmaker_key,
                raw_market.get("key") if isinstance(raw_market, Mapping) else "?",
                exc,
            )


def parse_event(raw: Mapping[str, Any]) -> Event:
    """Convierte un evento del JSON de la API en :class:`Event`.

    Raises:
        KeyError: Si faltan campos obligatorios (``id``, ``sport_key``, ``commence_time``).
        ValueError: Si algún campo tiene un formato inválido.
    """
    markets: list[BookmakerMarket] = []
    for raw_bookmaker in raw.get("bookmakers") or []:
        markets.extend(_parse_bookmaker_markets(raw_bookmaker))
    return Event(
        id=str(raw["id"]),
        sport_key=str(raw["sport_key"]),
        sport_title=str(raw.get("sport_title") or raw["sport_key"]),
        commence_time=_parse_datetime(raw["commence_time"]),
        home_team=str(raw.get("home_team") or ""),
        away_team=str(raw.get("away_team") or ""),
        markets=tuple(markets),
    )


def parse_events(payload: Any) -> list[Event]:
    """Convierte la respuesta de ``/sports/{sport}/odds`` en una lista de eventos.

    Raises:
        OddsApiResponseError: Si el payload no es una lista JSON.
    """
    if not isinstance(payload, list):
        raise OddsApiResponseError(
            f"Se esperaba una lista de eventos y se recibió {type(payload).__name__}."
        )
    events: list[Event] = []
    skipped = 0
    for raw in payload:
        try:
            events.append(parse_event(raw))
        except (KeyError, TypeError, ValueError, AttributeError) as exc:
            skipped += 1
            logger.debug("Evento malformado descartado: %s", exc)
    if skipped:
        logger.warning("Se descartaron %d evento(s) malformado(s) de la respuesta.", skipped)
    return events


def parse_sports(payload: Any) -> list[Sport]:
    """Convierte la respuesta de ``/sports`` en una lista de :class:`Sport`.

    Raises:
        OddsApiResponseError: Si el payload no es una lista JSON.
    """
    if not isinstance(payload, list):
        raise OddsApiResponseError(
            f"Se esperaba una lista de deportes y se recibió {type(payload).__name__}."
        )
    sports: list[Sport] = []
    for raw in payload:
        try:
            sports.append(
                Sport(
                    key=str(raw["key"]),
                    group=str(raw.get("group") or ""),
                    title=str(raw.get("title") or raw["key"]),
                    description=str(raw.get("description") or ""),
                    active=bool(raw.get("active", True)),
                    has_outrights=bool(raw.get("has_outrights", False)),
                )
            )
        except (KeyError, TypeError) as exc:
            logger.debug("Deporte malformado descartado: %s", exc)
    return sports
