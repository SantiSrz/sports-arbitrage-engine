"""Selección y saneado de mercados comparables dentro de un evento.

Antes de calcular arbitraje o valor hay que asegurarse de comparar "manzanas
con manzanas": mismo mercado, mismo conjunto de resultados, datos frescos y una
sola entrada por casa. Este módulo lo centraliza para los dos motores.
"""

from __future__ import annotations

from collections import defaultdict
from collections.abc import Collection
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone

from .models import DRAW_OUTCOME_NAME, BookmakerMarket, Event, MarketStructure

#: Mercados que el motor sabe analizar (ganador 2 vías / 1X2 con empate).
SUPPORTED_MARKETS: frozenset[str] = frozenset({"h2h", "h2h_3_way"})

_MIN_DATETIME = datetime.min.replace(tzinfo=timezone.utc)


@dataclass(frozen=True, slots=True)
class MarketSnapshot:
    """Conjunto homogéneo de cuotas de un mercado de un evento.

    Attributes:
        market_key: Clave del mercado (``h2h``...).
        structure: 2 o 3 vías.
        outcome_names: Resultados en orden canónico (local, empate, visitante).
        entries: Una entrada por casa, ordenadas por clave; todas con exactamente
            los resultados de ``outcome_names``.
    """

    market_key: str
    structure: MarketStructure
    outcome_names: tuple[str, ...]
    entries: tuple[BookmakerMarket, ...]


def order_outcome_names(event: Event, names: Collection[str]) -> tuple[str, ...]:
    """Ordena los resultados como 1-X-2: local, empate, visitante y el resto."""
    remaining = set(names)
    ordered: list[str] = []
    for preferred in (event.home_team, DRAW_OUTCOME_NAME, event.away_team):
        if preferred in remaining:
            ordered.append(preferred)
            remaining.discard(preferred)
    ordered.extend(sorted(remaining))
    return tuple(ordered)


def _is_fresh(market: BookmakerMarket, now: datetime, max_age: timedelta | None) -> bool:
    if max_age is None or market.last_update is None:
        return True
    return now - market.last_update <= max_age


def _is_well_formed(market: BookmakerMarket) -> bool:
    """2 resultados sin empate o 3 resultados con empate, sin nombres repetidos."""
    names = market.outcome_names
    if len(market.outcomes) != len(names):
        return False
    if len(names) == 2:
        return DRAW_OUTCOME_NAME not in names
    if len(names) == 3:
        return DRAW_OUTCOME_NAME in names
    return False


def _dedupe_bookmakers(markets: list[BookmakerMarket]) -> list[BookmakerMarket]:
    """Conserva la entrada más reciente de cada casa."""
    latest: dict[str, BookmakerMarket] = {}
    for market in markets:
        current = latest.get(market.bookmaker_key)
        if current is None or (market.last_update or _MIN_DATETIME) > (
            current.last_update or _MIN_DATETIME
        ):
            latest[market.bookmaker_key] = market
    return list(latest.values())


def build_market_snapshots(
    event: Event,
    *,
    now: datetime,
    max_odds_age: timedelta | None = None,
    include_live: bool = False,
    market_keys: Collection[str] = SUPPORTED_MARKETS,
    min_bookmakers: int = 2,
) -> list[MarketSnapshot]:
    """Agrupa las cuotas de un evento en snapshots homogéneos por mercado.

    Args:
        event: Evento con las cuotas de todas las casas.
        now: Instante de referencia (UTC) para medir la antigüedad de las cuotas.
        max_odds_age: Descarta cuotas con ``last_update`` más antiguo que esto.
        include_live: Si es ``False`` se ignoran eventos ya comenzados (cuotas
            en directo, muy volátiles y propensas a falsos positivos).
        market_keys: Mercados a considerar.
        min_bookmakers: Nº mínimo de casas comparables para emitir el snapshot.
    """
    if not include_live and event.commence_time <= now:
        return []

    snapshots: list[MarketSnapshot] = []
    for market_key in sorted(set(market_keys)):
        candidates = [
            m
            for m in event.markets
            if m.market_key == market_key and _is_well_formed(m) and _is_fresh(m, now, max_odds_age)
        ]
        candidates = _dedupe_bookmakers(candidates)
        if len(candidates) < min_bookmakers:
            continue

        groups: dict[frozenset[str], list[BookmakerMarket]] = defaultdict(list)
        for market in candidates:
            groups[market.outcome_names].append(market)

        # Si hay conjuntos de resultados heterogéneos, nos quedamos con el mayoritario.
        names, entries = max(
            groups.items(), key=lambda kv: (len(kv[1]), len(kv[0]), sorted(kv[0]))
        )
        if len(entries) < min_bookmakers:
            continue

        snapshots.append(
            MarketSnapshot(
                market_key=market_key,
                structure=(
                    MarketStructure.THREE_WAY if len(names) == 3 else MarketStructure.TWO_WAY
                ),
                outcome_names=order_outcome_names(event, names),
                entries=tuple(sorted(entries, key=lambda m: m.bookmaker_key)),
            )
        )
    return snapshots
