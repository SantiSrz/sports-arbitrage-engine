"""CLI de ejecución del motor de surebets/valuebets.

Ejemplos::

    python -m surebet_engine sports
    python -m surebet_engine surebets --sport soccer_spain_la_liga --regions eu,uk --bankroll 100
    python -m surebet_engine valuebets --sport tennis_atp_paris_masters --sharp pinnacle
    python -m surebet_engine surebets --from-file examples/sample_odds.json --max-age 0

Códigos de salida: 0 = OK, 1 = error de API/ejecución, 2 = error de configuración/uso.
"""

from __future__ import annotations

import argparse
import json
import logging
import sys
from collections.abc import Sequence
from datetime import timedelta
from decimal import Decimal, InvalidOperation
from pathlib import Path
from typing import Any

from .config import Settings
from .exceptions import (
    ConfigurationError,
    OddsApiAuthenticationError,
    OddsApiQuotaExceededError,
    SurebetEngineError,
)
from .market_selection import SUPPORTED_MARKETS
from .models import ArbitrageOpportunity, Event, QuotaInfo, ValueBet, quantize
from .odds_api_client import OddsApiClient
from .parsing import parse_events, parse_sports
from .scanner import OddsScanner, scan_surebets, scan_valuebets
from .valuebet import MarginRemovalMethod

logger = logging.getLogger("surebet_engine")

_HUNDRED = Decimal(100)


# --------------------------------------------------------------------------- #
# Tipos de argumento
# --------------------------------------------------------------------------- #
def _decimal(value: str) -> Decimal:
    try:
        parsed = Decimal(value)
    except InvalidOperation:
        raise argparse.ArgumentTypeError(f"'{value}' no es un número válido.") from None
    if not parsed.is_finite():
        raise argparse.ArgumentTypeError(f"'{value}' no es un número finito.")
    return parsed


def _positive_decimal(value: str) -> Decimal:
    parsed = _decimal(value)
    if parsed <= 0:
        raise argparse.ArgumentTypeError("debe ser > 0.")
    return parsed


def _non_negative_decimal(value: str) -> Decimal:
    parsed = _decimal(value)
    if parsed < 0:
        raise argparse.ArgumentTypeError("no puede ser negativo.")
    return parsed


def _csv(value: str) -> tuple[str, ...]:
    return tuple(item.strip() for item in value.split(",") if item.strip())


def _markets(value: str) -> tuple[str, ...]:
    markets = _csv(value)
    unsupported = [m for m in markets if m not in SUPPORTED_MARKETS]
    if not markets or unsupported:
        raise argparse.ArgumentTypeError(
            f"mercados no soportados: {unsupported or value!r}. "
            f"Disponibles: {', '.join(sorted(SUPPORTED_MARKETS))}."
        )
    return markets


# --------------------------------------------------------------------------- #
# Parser
# --------------------------------------------------------------------------- #
def build_parser() -> argparse.ArgumentParser:
    """Construye el parser de argumentos con sus subcomandos."""
    parser = argparse.ArgumentParser(
        prog="surebet_engine",
        description="Detector de surebets y valuebets sobre The Odds API v4.",
    )
    subparsers = parser.add_subparsers(dest="command", required=True, metavar="COMANDO")

    logging_parent = argparse.ArgumentParser(add_help=False)
    logging_parent.add_argument(
        "-v", "--verbose", action="count", default=0, help="-v = INFO, -vv = DEBUG"
    )

    scan_parent = argparse.ArgumentParser(add_help=False, parents=[logging_parent])
    scan_parent.add_argument(
        "--sport",
        action="append",
        metavar="CLAVE",
        help="Clave de deporte (repetible), p. ej. soccer_epl. 'upcoming' = próximos eventos.",
    )
    scan_parent.add_argument("--regions", type=_csv, help="Regiones (def.: ODDS_API_REGIONS o eu).")
    scan_parent.add_argument(
        "--bookmakers", type=_csv, help="Claves de casas; si se indican, se ignoran las regiones."
    )
    scan_parent.add_argument(
        "--markets", type=_markets, default=("h2h",), help="Mercados (def.: h2h)."
    )
    scan_parent.add_argument(
        "--bankroll", type=_positive_decimal, help="Bankroll total (def.: DEFAULT_BANKROLL o 100)."
    )
    scan_parent.add_argument(
        "--max-age",
        type=float,
        default=900.0,
        metavar="SEG",
        help="Descarta cuotas más antiguas que SEG segundos (def.: 900; 0 = sin límite).",
    )
    scan_parent.add_argument(
        "--include-live", action="store_true", help="Incluye eventos en directo (más riesgo)."
    )
    scan_parent.add_argument(
        "--from-file",
        type=Path,
        metavar="RUTA",
        help="Analiza un JSON guardado de /odds en lugar de llamar a la API (0 créditos).",
    )
    scan_parent.add_argument("--currency", default="€", help="Símbolo de moneda (def.: €).")
    scan_parent.add_argument("--json", action="store_true", help="Salida en JSON.")

    sports = subparsers.add_parser(
        "sports", parents=[logging_parent], help="Lista los deportes disponibles."
    )
    sports.add_argument("--all", action="store_true", help="Incluye deportes fuera de temporada.")

    surebets = subparsers.add_parser(
        "surebets", parents=[scan_parent], help="Detecta surebets (arbitraje)."
    )
    surebets.add_argument(
        "--min-margin",
        type=_non_negative_decimal,
        default=Decimal(0),
        metavar="PCT",
        help="Margen de arbitraje mínimo en %% (def.: 0).",
    )
    surebets.add_argument(
        "--round-step",
        type=_positive_decimal,
        default=Decimal(1),
        metavar="PASO",
        help="Redondea stakes a múltiplos de PASO (def.: 1 = enteros).",
    )
    surebets.add_argument(
        "--no-round", action="store_true", help="Desactiva el redondeo de stakes."
    )

    valuebets = subparsers.add_parser(
        "valuebets", parents=[scan_parent], help="Detecta apuestas de valor."
    )
    valuebets.add_argument(
        "--min-edge",
        type=_non_negative_decimal,
        default=Decimal(2),
        metavar="PCT",
        help="Valor esperado mínimo en %% (def.: 2).",
    )
    valuebets.add_argument(
        "--sharp", metavar="CASA", help="Casa de referencia (p. ej. pinnacle). Def.: consenso."
    )
    valuebets.add_argument(
        "--min-refs",
        type=int,
        default=3,
        help="Mínimo de casas de referencia en modo consenso (def.: 3).",
    )
    valuebets.add_argument(
        "--margin-method",
        choices=[m.value for m in MarginRemovalMethod],
        default=MarginRemovalMethod.MULTIPLICATIVE.value,
        help="Método para quitar el margen (def.: multiplicative).",
    )
    valuebets.add_argument(
        "--kelly",
        type=_non_negative_decimal,
        default=Decimal("0.25"),
        help="Fracción de Kelly aplicada (def.: 0.25).",
    )
    valuebets.add_argument(
        "--max-stake-pct",
        type=_non_negative_decimal,
        default=Decimal(5),
        help="Tope de stake en %% del bankroll (def.: 5).",
    )
    return parser


# --------------------------------------------------------------------------- #
# Formato de salida
# --------------------------------------------------------------------------- #
def _money(value: Decimal, currency: str) -> str:
    return f"{quantize(value)}{currency}"


def _odds(value: Decimal) -> str:
    """Cuota con 2 decimales (2.10); conserva más precisión si la cuota la tiene (1.909)."""
    two = value.quantize(Decimal("0.01"))
    return format(two, "f") if two == value else format(value.normalize(), "f")


def _plain(value: Decimal) -> str:
    """Decimal sin notación científica ni ceros sobrantes (49, 24.5...)."""
    return format(value.normalize(), "f")


def _table(headers: Sequence[str], rows: Sequence[Sequence[str]], indent: str = "    ") -> str:
    widths = [max(len(str(c)) for c in col) for col in zip(headers, *rows, strict=True)]
    lines = [indent + "  ".join(h.ljust(w) for h, w in zip(headers, widths, strict=True)).rstrip()]
    lines.append(indent + "  ".join("-" * w for w in widths))
    for row in rows:
        cells = "  ".join(str(c).ljust(w) for c, w in zip(row, widths, strict=True))
        lines.append(indent + cells.rstrip())
    return "\n".join(lines)


def _event_header(event: Event) -> str:
    when = event.commence_time.strftime("%Y-%m-%d %H:%M UTC")
    return f"{event.label}  [{event.sport_key}]  {when}"


def render_surebet(index: int, opp: ArbitrageOpportunity, currency: str) -> str:
    """Renderiza una surebet como texto legible."""
    plan = opp.practical_plan
    profits = plan.profits
    rows: list[list[str]] = []
    for i, leg in enumerate(opp.legs):
        rows.append(
            [
                leg.outcome,
                leg.bookmaker_title,
                _odds(leg.odds),
                _money(opp.theoretical_plan.stakes[i], currency),
                _plain(opp.rounded_plan.stakes[i]) + currency if opp.rounded_plan else "-",
                _money(profits[i], currency),
            ]
        )
    lines = [
        f"#{index}  {_event_header(opp.event)}",
        f"    Mercado {opp.market_key} ({opp.structure.value}) | "
        f"Σ(1/cuota) = {quantize(opp.implied_sum, 6)} | "
        f"Margen = {quantize(opp.margin * _HUNDRED, 2)}% | "
        f"ROI teórico = {quantize(opp.roi * _HUNDRED, 2)}%",
        _table(
            ["Resultado", "Casa", "Cuota", "Stake teórico", "Stake redond.", "Beneficio si acierta"],
            rows,
        ),
        f"    Beneficio garantizado teórico: {_money(opp.theoretical_plan.guaranteed_profit, currency)}"
        f" (bankroll {_money(opp.bankroll, currency)})",
    ]
    if opp.rounded_plan is not None:
        rp = opp.rounded_plan
        status = "" if rp.guaranteed_profit > 0 else "  ⚠ SIN BENEFICIO tras redondear"
        lines.append(
            f"    Con stakes redondeados: capital {_money(rp.total_stake, currency)} | "
            f"beneficio mínimo {_money(rp.guaranteed_profit, currency)} "
            f"(pérdida por redondeo {_money(opp.rounding_loss, currency)}){status}"
        )
    return "\n".join(lines)


def render_valuebet(index: int, vb: ValueBet, currency: str) -> str:
    """Renderiza una valuebet como texto legible."""
    return "\n".join(
        [
            f"#{index}  {_event_header(vb.event)}",
            f"    {vb.outcome} @ {_odds(vb.odds)} en {vb.bookmaker_title} ({vb.market_key})",
            f"    Prob. justa = {quantize(vb.fair_probability * _HUNDRED, 2)}% "
            f"(cuota justa {quantize(vb.fair_odds, 3)}) | "
            f"EV = +{quantize(vb.expected_value * _HUNDRED, 2)}% | "
            f"Kelly completo = {quantize(vb.kelly_fraction * _HUNDRED, 2)}%",
            f"    Stake sugerido: {_money(vb.recommended_stake, currency)} "
            f"| referencia: {vb.reference_label} ({vb.reference_count} casa/s)",
        ]
    )


def _quota_line(quota: QuotaInfo | None) -> str | None:
    if quota is None or (quota.remaining is None and quota.used is None):
        return None
    return (
        f"Créditos API → restantes: {quota.remaining if quota.remaining is not None else '?'} | "
        f"usados: {quota.used if quota.used is not None else '?'} | "
        f"último coste: {quota.last_cost if quota.last_cost is not None else '?'}"
    )


def _quota_dict(quota: QuotaInfo | None) -> dict[str, int | None] | None:
    if quota is None:
        return None
    return {"remaining": quota.remaining, "used": quota.used, "last_cost": quota.last_cost}


# --------------------------------------------------------------------------- #
# Ejecución
# --------------------------------------------------------------------------- #
def _configure_logging(verbosity: int) -> None:
    level = logging.WARNING if verbosity <= 0 else logging.INFO if verbosity == 1 else logging.DEBUG
    logging.basicConfig(level=level, format="%(levelname)s %(name)s: %(message)s", stream=sys.stderr)


def _load_events(args: argparse.Namespace, settings: Settings) -> tuple[list[Event], QuotaInfo | None]:
    """Obtiene eventos desde un fichero (offline) o desde la API."""
    if args.from_file:
        try:
            payload = json.loads(Path(args.from_file).read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise ConfigurationError(f"No se pudo leer {args.from_file}: {exc}") from exc
        return parse_events(payload), None

    if not args.sport:
        raise ConfigurationError("Indica al menos un --sport (o usa --from-file).")

    with OddsApiClient(
        settings.api_key,
        timeout=settings.request_timeout,
        low_quota_threshold=settings.low_quota_threshold,
    ) as client:
        events = OddsScanner(client).fetch_events(
            args.sport,
            regions=args.regions or settings.regions,
            markets=args.markets,
            bookmakers=args.bookmakers,
        )
        return events, client.last_quota


def _emit(payload: dict[str, Any]) -> None:
    print(json.dumps(payload, ensure_ascii=False, indent=2))


def _cmd_sports(args: argparse.Namespace, settings: Settings) -> int:
    with OddsApiClient(
        settings.api_key,
        timeout=settings.request_timeout,
        low_quota_threshold=settings.low_quota_threshold,
    ) as client:
        response = client.get_sports(all_sports=args.all)
        sports = parse_sports(response.data)
    rows = [[s.key, s.group, s.title, "sí" if s.active else "no"] for s in sports]
    print(_table(["Clave", "Grupo", "Título", "Activo"], rows, indent=""))
    quota_line = _quota_line(response.quota)
    if quota_line:
        print(quota_line, file=sys.stderr)
    return 0


def _cmd_surebets(args: argparse.Namespace, settings: Settings) -> int:
    bankroll: Decimal = args.bankroll or settings.default_bankroll
    events, quota = _load_events(args, settings)
    opportunities = scan_surebets(
        events,
        bankroll=bankroll,
        min_margin=args.min_margin / _HUNDRED,
        round_step=None if args.no_round else args.round_step,
        max_odds_age=timedelta(seconds=args.max_age) if args.max_age > 0 else None,
        include_live=args.include_live,
    )
    if args.json:
        _emit(
            {
                "events_analyzed": len(events),
                "count": len(opportunities),
                "quota": _quota_dict(quota),
                "surebets": [o.to_dict() for o in opportunities],
            }
        )
    else:
        print(f"Eventos analizados: {len(events)} | Surebets encontradas: {len(opportunities)}\n")
        for i, opportunity in enumerate(opportunities, start=1):
            print(render_surebet(i, opportunity, args.currency), end="\n\n")
    quota_line = _quota_line(quota)
    if quota_line:
        print(quota_line, file=sys.stderr)
    return 0


def _cmd_valuebets(args: argparse.Namespace, settings: Settings) -> int:
    bankroll: Decimal = args.bankroll or settings.default_bankroll
    events, quota = _load_events(args, settings)
    value_bets = scan_valuebets(
        events,
        bankroll=bankroll,
        min_edge=args.min_edge / _HUNDRED,
        sharp_bookmaker=args.sharp,
        min_reference_bookmakers=args.min_refs,
        margin_method=MarginRemovalMethod(args.margin_method),
        kelly_multiplier=args.kelly,
        max_stake_fraction=args.max_stake_pct / _HUNDRED,
        max_odds_age=timedelta(seconds=args.max_age) if args.max_age > 0 else None,
        include_live=args.include_live,
    )
    if args.json:
        _emit(
            {
                "events_analyzed": len(events),
                "count": len(value_bets),
                "quota": _quota_dict(quota),
                "valuebets": [v.to_dict() for v in value_bets],
            }
        )
    else:
        print(f"Eventos analizados: {len(events)} | Valuebets encontradas: {len(value_bets)}\n")
        for i, value_bet in enumerate(value_bets, start=1):
            print(render_valuebet(i, value_bet, args.currency), end="\n\n")
    quota_line = _quota_line(quota)
    if quota_line:
        print(quota_line, file=sys.stderr)
    return 0


def main(argv: Sequence[str] | None = None) -> int:
    """Punto de entrada de la CLI. Devuelve el código de salida del proceso."""
    parser = build_parser()
    args = parser.parse_args(argv)
    _configure_logging(args.verbose)

    try:
        settings = Settings.from_env(require_api_key=not getattr(args, "from_file", None))
        if args.command == "sports":
            return _cmd_sports(args, settings)
        if args.command == "surebets":
            return _cmd_surebets(args, settings)
        return _cmd_valuebets(args, settings)
    except ConfigurationError as exc:
        print(f"Error de configuración: {exc}", file=sys.stderr)
        return 2
    except OddsApiQuotaExceededError as exc:
        print(f"Créditos agotados: {exc}", file=sys.stderr)
        return 1
    except OddsApiAuthenticationError as exc:
        print(f"API key rechazada: {exc}", file=sys.stderr)
        return 1
    except SurebetEngineError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        print("Interrumpido por el usuario.", file=sys.stderr)
        return 130


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
