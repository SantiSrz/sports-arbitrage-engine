"""Modelos de dominio tipados (dataclasses inmutables) del motor.

Todas las cuotas y cantidades monetarias usan :class:`decimal.Decimal` para
evitar los errores de coma flotante propios de los cálculos financieros.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from decimal import ROUND_HALF_UP, Decimal
from enum import Enum
from typing import Any

from .exceptions import InvalidOddsError

#: Nombre con el que The Odds API etiqueta el empate en mercados 1X2.
DRAW_OUTCOME_NAME = "Draw"

_ONE = Decimal(1)


def quantize(value: Decimal, places: int = 2) -> Decimal:
    """Redondea ``value`` a ``places`` decimales (mitad hacia arriba)."""
    return value.quantize(Decimal(1).scaleb(-places), rounding=ROUND_HALF_UP)


class MarketStructure(str, Enum):
    """Número de resultados mutuamente excluyentes del mercado."""

    TWO_WAY = "2-way"  # tenis, baloncesto, MMA...
    THREE_WAY = "3-way"  # fútbol 1X2 (local / empate / visitante)


# --------------------------------------------------------------------------- #
# Modelos de la API
# --------------------------------------------------------------------------- #
@dataclass(frozen=True, slots=True)
class QuotaInfo:
    """Consumo del plan leído de las cabeceras ``x-requests-*``."""

    remaining: int | None = None
    used: int | None = None
    last_cost: int | None = None


@dataclass(frozen=True, slots=True)
class Sport:
    """Deporte / competición disponible en la API."""

    key: str
    group: str
    title: str
    description: str
    active: bool
    has_outrights: bool


@dataclass(frozen=True, slots=True)
class Outcome:
    """Un resultado de un mercado con su cuota decimal."""

    name: str
    price: Decimal

    def __post_init__(self) -> None:
        if not self.price.is_finite() or self.price <= _ONE:
            raise InvalidOddsError(
                f"Cuota decimal inválida para '{self.name}': {self.price} (debe ser > 1.0)"
            )


@dataclass(frozen=True, slots=True)
class BookmakerMarket:
    """Mercado ofrecido por una casa de apuestas concreta."""

    bookmaker_key: str
    bookmaker_title: str
    market_key: str
    outcomes: tuple[Outcome, ...]
    last_update: datetime | None = None

    @property
    def outcome_names(self) -> frozenset[str]:
        """Conjunto de nombres de resultado de este mercado."""
        return frozenset(o.name for o in self.outcomes)

    def price_for(self, outcome_name: str) -> Decimal | None:
        """Cuota del resultado ``outcome_name`` o ``None`` si no existe."""
        for outcome in self.outcomes:
            if outcome.name == outcome_name:
                return outcome.price
        return None


@dataclass(frozen=True, slots=True)
class Event:
    """Evento deportivo con las cuotas de todas las casas consultadas."""

    id: str
    sport_key: str
    sport_title: str
    commence_time: datetime
    home_team: str
    away_team: str
    markets: tuple[BookmakerMarket, ...]

    @property
    def label(self) -> str:
        """Etiqueta legible ``Local vs Visitante``."""
        return f"{self.home_team} vs {self.away_team}"


# --------------------------------------------------------------------------- #
# Modelos de resultados del motor
# --------------------------------------------------------------------------- #
@dataclass(frozen=True, slots=True)
class StakePlan:
    """Reparto de stakes y su rentabilidad en el peor escenario.

    Attributes:
        stakes: Importe apostado en cada resultado (mismo orden que las cuotas).
        payouts: Retorno bruto si acierta cada resultado (``stake * cuota``).
        total_stake: Capital total comprometido.
        guaranteed_profit: ``min(payouts) - total_stake``; beneficio garantizado
            en el peor de los escenarios.
    """

    stakes: tuple[Decimal, ...]
    payouts: tuple[Decimal, ...]
    total_stake: Decimal
    guaranteed_profit: Decimal

    @property
    def profits(self) -> tuple[Decimal, ...]:
        """Beneficio neto para cada resultado posible."""
        return tuple(p - self.total_stake for p in self.payouts)

    @property
    def roi(self) -> Decimal:
        """Beneficio garantizado sobre el capital comprometido (fracción)."""
        if self.total_stake == 0:
            return Decimal(0)
        return self.guaranteed_profit / self.total_stake

    def to_dict(self) -> dict[str, Any]:
        """Representación serializable a JSON."""
        return {
            "stakes": [str(quantize(s)) for s in self.stakes],
            "total_stake": str(quantize(self.total_stake)),
            "profit_per_outcome": [str(quantize(p)) for p in self.profits],
            "guaranteed_profit": str(quantize(self.guaranteed_profit)),
            "roi_pct": str(quantize(self.roi * 100, 4)),
        }


@dataclass(frozen=True, slots=True)
class ArbitrageLeg:
    """Pata de una surebet: mejor cuota disponible para un resultado."""

    outcome: str
    bookmaker_key: str
    bookmaker_title: str
    odds: Decimal
    implied_probability: Decimal


@dataclass(frozen=True, slots=True)
class ArbitrageOpportunity:
    """Surebet detectada.

    Attributes:
        implied_sum: Σ (1 / cuota). Hay arbitraje si es estrictamente < 1.
        margin: Margen de arbitraje ``1 - implied_sum``.
        roi: Rentabilidad garantizada ``1 / implied_sum - 1`` sobre el capital.
        bankroll: Capital total a repartir.
        theoretical_plan: Reparto exacto (importes fraccionarios).
        rounded_plan: Reparto con stakes redondeados (enteros por defecto).
    """

    event: Event
    market_key: str
    structure: MarketStructure
    legs: tuple[ArbitrageLeg, ...]
    implied_sum: Decimal
    margin: Decimal
    roi: Decimal
    bankroll: Decimal
    theoretical_plan: StakePlan
    rounded_plan: StakePlan | None = None
    detected_at: datetime | None = None

    @property
    def practical_plan(self) -> StakePlan:
        """Plan ejecutable: el redondeado si existe, si no el teórico."""
        return self.rounded_plan if self.rounded_plan is not None else self.theoretical_plan

    @property
    def rounding_loss(self) -> Decimal:
        """Beneficio teórico perdido por el redondeo de stakes."""
        if self.rounded_plan is None:
            return Decimal(0)
        return self.theoretical_plan.guaranteed_profit - self.rounded_plan.guaranteed_profit

    def to_dict(self) -> dict[str, Any]:
        """Representación serializable a JSON."""
        legs: list[dict[str, Any]] = []
        for index, leg in enumerate(self.legs):
            legs.append(
                {
                    "outcome": leg.outcome,
                    "bookmaker": leg.bookmaker_key,
                    "odds": str(leg.odds),
                    "implied_probability": str(quantize(leg.implied_probability, 6)),
                    "theoretical_stake": str(quantize(self.theoretical_plan.stakes[index])),
                    "rounded_stake": (
                        str(quantize(self.rounded_plan.stakes[index]))
                        if self.rounded_plan is not None
                        else None
                    ),
                }
            )
        return {
            "event_id": self.event.id,
            "sport_key": self.event.sport_key,
            "commence_time": self.event.commence_time.isoformat(),
            "home_team": self.event.home_team,
            "away_team": self.event.away_team,
            "market": self.market_key,
            "structure": self.structure.value,
            "implied_sum": str(quantize(self.implied_sum, 6)),
            "margin_pct": str(quantize(self.margin * 100, 4)),
            "roi_pct": str(quantize(self.roi * 100, 4)),
            "bankroll": str(quantize(self.bankroll)),
            "legs": legs,
            "theoretical_plan": self.theoretical_plan.to_dict(),
            "rounded_plan": self.rounded_plan.to_dict() if self.rounded_plan else None,
            "detected_at": self.detected_at.isoformat() if self.detected_at else None,
        }


@dataclass(frozen=True, slots=True)
class ValueBet:
    """Apuesta de valor: cuota superior a la cuota justa estimada.

    Attributes:
        fair_probability: Probabilidad real estimada (sin margen de la casa).
        fair_odds: Cuota justa ``1 / fair_probability``.
        expected_value: Valor esperado por unidad apostada ``p * cuota - 1``.
        kelly_fraction: Fracción de Kelly completa del bankroll.
        recommended_stake: Stake sugerido (Kelly fraccional con tope).
        reference_count: Nº de casas usadas como referencia.
        reference_label: ``consensus`` o la clave de la casa "sharp" usada.
    """

    event: Event
    market_key: str
    outcome: str
    bookmaker_key: str
    bookmaker_title: str
    odds: Decimal
    fair_probability: Decimal
    fair_odds: Decimal
    expected_value: Decimal
    kelly_fraction: Decimal
    recommended_stake: Decimal
    reference_count: int
    reference_label: str

    def to_dict(self) -> dict[str, Any]:
        """Representación serializable a JSON."""
        return {
            "event_id": self.event.id,
            "sport_key": self.event.sport_key,
            "commence_time": self.event.commence_time.isoformat(),
            "home_team": self.event.home_team,
            "away_team": self.event.away_team,
            "market": self.market_key,
            "outcome": self.outcome,
            "bookmaker": self.bookmaker_key,
            "odds": str(self.odds),
            "fair_probability": str(quantize(self.fair_probability, 6)),
            "fair_odds": str(quantize(self.fair_odds, 4)),
            "expected_value_pct": str(quantize(self.expected_value * 100, 4)),
            "kelly_fraction_pct": str(quantize(self.kelly_fraction * 100, 4)),
            "recommended_stake": str(quantize(self.recommended_stake)),
            "reference_count": self.reference_count,
            "reference": self.reference_label,
        }
